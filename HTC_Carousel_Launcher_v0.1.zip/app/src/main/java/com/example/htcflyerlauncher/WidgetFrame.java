package com.example.htcflyerlauncher;

import android.appwidget.AppWidgetHostView;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;
import android.widget.TextView;

public class WidgetFrame extends FrameLayout {
    public interface ResizeListener { void onResize(int spanX,int spanY); void onRemove(); void onEditRequested(); void onDone(); }
    private final AppWidgetHostView host;
    private final View tl,tr,bl,br;
    private final TextView remove,ok;
    private ResizeListener listener;
    private int maxColumns=5,maxRows=4;
    private boolean editMode=false;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final int touchSlop;
    private float downX,downY;
    private boolean longPressTriggered=false;
    private final Runnable longPressRunnable=()->{ longPressTriggered=true; if(listener!=null) listener.onEditRequested(); setEditMode(true); };

    public WidgetFrame(Context c,AppWidgetHostView h){
        super(c); host=h; touchSlop=ViewConfiguration.get(c).getScaledTouchSlop();
        setClipChildren(false); setClipToPadding(false); setClickable(true); setLongClickable(true);
        addView(host,new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT));
        tl=corner(); tr=corner(); bl=corner(); br=corner();
        addCorner(tl,Gravity.TOP|Gravity.LEFT); addCorner(tr,Gravity.TOP|Gravity.RIGHT);
        addCorner(bl,Gravity.BOTTOM|Gravity.LEFT); addCorner(br,Gravity.BOTTOM|Gravity.RIGHT);
        installDrag(tl,-1,-1); installDrag(tr,1,-1); installDrag(bl,-1,1); installDrag(br,1,1);
        remove=new TextView(c); remove.setText("×"); remove.setTextColor(Color.WHITE); remove.setTextSize(20); remove.setGravity(Gravity.CENTER);
        GradientDrawable rb=new GradientDrawable(); rb.setColor(0xD9222222); rb.setShape(GradientDrawable.OVAL); remove.setBackground(rb);
        LayoutParams rp=new LayoutParams(dp(34),dp(34)); rp.gravity=Gravity.TOP|Gravity.CENTER_HORIZONTAL; rp.topMargin=-dp(17); addView(remove,rp);
        remove.setOnClickListener(v->{ if(listener!=null) listener.onRemove(); });

        ok=new TextView(c); ok.setText("OK"); ok.setTextColor(Color.WHITE); ok.setTextSize(14); ok.setGravity(Gravity.CENTER);
        GradientDrawable ob=new GradientDrawable(); ob.setColor(0xE5227A35); ob.setCornerRadius(dp(16)); ok.setBackground(ob);
        LayoutParams op=new LayoutParams(dp(58),dp(34)); op.gravity=Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL; op.bottomMargin=-dp(17); addView(ok,op);
        ok.setOnClickListener(v->{
            handler.removeCallbacks(longPressRunnable);
            longPressTriggered=false;
            setEditMode(false);
            if(listener!=null) listener.onDone();
        });

        // The launcher owns widget long-press for resize mode.
        host.setLongClickable(false);
        setEditMode(false);
    }
    public AppWidgetHostView getHost(){return host;}
    public void setGridLimits(int c,int r){maxColumns=Math.max(1,c);maxRows=Math.max(1,r);}
    public void setResizeListener(ResizeListener l){listener=l;}
    public void setEditMode(boolean enabled){
        editMode=enabled; handler.removeCallbacks(longPressRunnable); longPressTriggered=false;
        int v=enabled?VISIBLE:GONE; tl.setVisibility(v);tr.setVisibility(v);bl.setVisibility(v);br.setVisibility(v);remove.setVisibility(v);ok.setVisibility(v);
        if(enabled){ GradientDrawable bg=new GradientDrawable(); bg.setColor(0x08000000); bg.setStroke(dp(2),0xFFFFFFFF); setBackground(bg); tl.bringToFront();tr.bringToFront();bl.bringToFront();br.bringToFront();remove.bringToFront();ok.bringToFront(); }
        else setBackgroundColor(Color.TRANSPARENT);
    }
    private View corner(){ View v=new View(getContext()); GradientDrawable g=new GradientDrawable(); g.setColor(Color.WHITE); g.setShape(GradientDrawable.OVAL); g.setStroke(dp(2),0xFF333333); v.setBackground(g); return v; }
    private void addCorner(View v,int gravity){ LayoutParams lp=new LayoutParams(dp(22),dp(22));lp.gravity=gravity;lp.setMargins(-dp(9),-dp(9),-dp(9),-dp(9));addView(v,lp); }
    private void installDrag(View handle,int xDir,int yDir){
        handle.setOnTouchListener(new OnTouchListener(){ float sx,sy; int startX,startY;
            public boolean onTouch(View v,MotionEvent e){
                if(e.getActionMasked()==MotionEvent.ACTION_DOWN){sx=e.getRawX();sy=e.getRawY();startX=spanX();startY=spanY();return true;}
                if(e.getActionMasked()==MotionEvent.ACTION_MOVE || e.getActionMasked()==MotionEvent.ACTION_UP){
                    float cellW=getParent() instanceof DesktopPageView?((DesktopPageView)getParent()).getWidth()/(float)maxColumns:getWidth();
                    float cellH=getParent() instanceof DesktopPageView?((DesktopPageView)getParent()).getHeight()/(float)maxRows:getHeight();
                    int dx=Math.round((e.getRawX()-sx)/Math.max(1f,cellW))*xDir;
                    int dy=Math.round((e.getRawY()-sy)/Math.max(1f,cellH))*yDir;
                    int nx=Math.max(1,Math.min(maxColumns,startX+dx)); int ny=Math.max(1,Math.min(maxRows,startY+dy));
                    setTag(R.id.desktop_span_x,nx);setTag(R.id.desktop_span_y,ny); if(listener!=null)listener.onResize(nx,ny);
                    return true;
                } return true;
            }});
    }
    private int spanX(){Integer v=(Integer)getTag(R.id.desktop_span_x);return v==null?1:v;}
    private int spanY(){Integer v=(Integer)getTag(R.id.desktop_span_y);return v==null?1:v;}
    @Override public boolean dispatchTouchEvent(MotionEvent e){
        if(!editMode){
            if(e.getActionMasked()==MotionEvent.ACTION_DOWN){downX=e.getX();downY=e.getY();longPressTriggered=false;handler.postDelayed(longPressRunnable,520);}
            else if(e.getActionMasked()==MotionEvent.ACTION_MOVE && (Math.abs(e.getX()-downX)>touchSlop||Math.abs(e.getY()-downY)>touchSlop)) handler.removeCallbacks(longPressRunnable);
            else if(e.getActionMasked()==MotionEvent.ACTION_UP||e.getActionMasked()==MotionEvent.ACTION_CANCEL){handler.removeCallbacks(longPressRunnable);if(longPressTriggered){longPressTriggered=false;return true;}}
        }
        return super.dispatchTouchEvent(e);
    }
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
