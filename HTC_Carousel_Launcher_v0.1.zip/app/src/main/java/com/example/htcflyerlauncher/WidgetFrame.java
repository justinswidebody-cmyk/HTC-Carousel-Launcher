package com.example.htcflyerlauncher;

import android.appwidget.AppWidgetHostView;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

public class WidgetFrame extends FrameLayout {
    public interface ResizeListener {
        void onResize(int spanX, int spanY);
        void onRemove();
    }

    private final AppWidgetHostView host;
    private final TextView minusW;
    private final TextView plusW;
    private final TextView minusH;
    private final TextView plusH;
    private final TextView remove;
    private ResizeListener resizeListener;
    private int maxColumns=4;
    private int maxRows=4;

    public WidgetFrame(Context context, AppWidgetHostView host) {
        super(context);
        this.host=host;
        setClipChildren(false);
        setClipToPadding(false);

        addView(host,new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT));

        minusW=handle("−W");
        plusW=handle("+W");
        minusH=handle("−H");
        plusH=handle("+H");
        remove=handle("×");

        addHandle(minusW,Gravity.LEFT|Gravity.CENTER_VERTICAL);
        addHandle(plusW,Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        addHandle(minusH,Gravity.TOP|Gravity.CENTER_HORIZONTAL);
        addHandle(plusH,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
        addHandle(remove,Gravity.TOP|Gravity.RIGHT);

        minusW.setOnClickListener(v->resizeBy(-1,0));
        plusW.setOnClickListener(v->resizeBy(1,0));
        minusH.setOnClickListener(v->resizeBy(0,-1));
        plusH.setOnClickListener(v->resizeBy(0,1));
        remove.setOnClickListener(v->{ if(resizeListener!=null) resizeListener.onRemove(); });

        setOnLongClickListener(v->{
            setEditMode(true);
            return true;
        });

        setEditMode(false);
    }

    public AppWidgetHostView getHost(){ return host; }

    public void setGridLimits(int columns,int rows){
        maxColumns=Math.max(1,columns);
        maxRows=Math.max(1,rows);
    }

    public void setResizeListener(ResizeListener l){ resizeListener=l; }

    public void setEditMode(boolean enabled){
        int vis=enabled?VISIBLE:GONE;
        minusW.setVisibility(vis);
        plusW.setVisibility(vis);
        minusH.setVisibility(vis);
        plusH.setVisibility(vis);
        remove.setVisibility(vis);
        if(enabled){
            GradientDrawable bg=new GradientDrawable();
            bg.setColor(0x08000000);
            bg.setStroke(dp(2),0xCCFFFFFF);
            bg.setCornerRadius(dp(8));
            setBackground(bg);
        }else{
            setBackgroundColor(Color.TRANSPARENT);
        }
    }

    private void resizeBy(int dx,int dy){
        Integer sxTag=(Integer)getTag(R.id.desktop_span_x);
        Integer syTag=(Integer)getTag(R.id.desktop_span_y);
        int sx=sxTag==null?1:sxTag;
        int sy=syTag==null?1:syTag;
        sx=Math.max(1,Math.min(maxColumns,sx+dx));
        sy=Math.max(1,Math.min(maxRows,sy+dy));
        setTag(R.id.desktop_span_x,sx);
        setTag(R.id.desktop_span_y,sy);
        if(resizeListener!=null) resizeListener.onResize(sx,sy);
    }

    private TextView handle(String text){
        TextView v=new TextView(getContext());
        v.setText(text);
        v.setTextColor(Color.WHITE);
        v.setTextSize(11);
        v.setGravity(Gravity.CENTER);
        GradientDrawable bg=new GradientDrawable();
        bg.setColor(0xE61B1D1F);
        bg.setStroke(dp(1),0xFFFFFFFF);
        bg.setCornerRadius(dp(14));
        v.setBackground(bg);
        return v;
    }

    private void addHandle(View v,int gravity){
        LayoutParams lp=new LayoutParams(dp(42),dp(30));
        lp.gravity=gravity;
        lp.setMargins(dp(2),dp(2),dp(2),dp(2));
        addView(v,lp);
    }

    private int dp(float v){ return Math.round(v*getResources().getDisplayMetrics().density); }
}
