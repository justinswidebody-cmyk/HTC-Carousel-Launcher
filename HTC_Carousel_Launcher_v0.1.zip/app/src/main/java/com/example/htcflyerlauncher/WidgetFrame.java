package com.example.htcflyerlauncher;

import android.appwidget.AppWidgetHostView;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;
import android.widget.TextView;

public class WidgetFrame extends FrameLayout {
    public interface ResizeListener {
        void onResize(int spanX,int spanY);
        void onRemove();
        void onEditRequested();
        void onDone();
    }

    private final AppWidgetHostView host;
    private final TextView minusW, plusW, minusH, plusH, remove, done;
    private ResizeListener resizeListener;
    private int maxColumns=4;
    private int maxRows=4;
    private boolean editMode=false;

    private final Handler handler=new Handler(Looper.getMainLooper());
    private final int touchSlop;
    private float downX, downY;
    private boolean longPressTriggered=false;

    private final Runnable longPressRunnable=()->{
        longPressTriggered=true;
        if(resizeListener!=null) resizeListener.onEditRequested();
        setEditMode(true);

    };

    public WidgetFrame(Context context,AppWidgetHostView host){
        super(context);
        this.host=host;
        touchSlop=ViewConfiguration.get(context).getScaledTouchSlop();
        setClipChildren(false);
        setClipToPadding(false);
        setClickable(true);
        setLongClickable(true);

        LayoutParams hostLp=new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT);
        addView(host,hostLp);

        minusW=handle("−W");
        plusW=handle("+W");
        minusH=handle("−H");
        plusH=handle("+H");
        remove=handle("×");
        done=handle("DONE");

        addHandle(minusW,Gravity.LEFT|Gravity.CENTER_VERTICAL);
        addHandle(plusW,Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        addHandle(minusH,Gravity.TOP|Gravity.CENTER_HORIZONTAL);
        addHandle(plusH,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
        addHandle(remove,Gravity.TOP|Gravity.RIGHT);
        addDoneHandle(done);

        minusW.setOnClickListener(v->resizeBy(-1,0));
        plusW.setOnClickListener(v->resizeBy(1,0));
        minusH.setOnClickListener(v->resizeBy(0,-1));
        plusH.setOnClickListener(v->resizeBy(0,1));
        remove.setOnClickListener(v->{ if(resizeListener!=null) resizeListener.onRemove(); });
        done.setOnClickListener(v->{ if(resizeListener!=null) resizeListener.onDone(); });

        setEditMode(false);
    }

    public AppWidgetHostView getHost(){ return host; }

    public void setGridLimits(int columns,int rows){
        maxColumns=Math.max(1,columns);
        maxRows=Math.max(1,rows);
    }

    public void setResizeListener(ResizeListener listener){
        resizeListener=listener;
    }

    public void setEditMode(boolean enabled){
        editMode=enabled;
        int vis=enabled?VISIBLE:GONE;
        minusW.setVisibility(vis);
        plusW.setVisibility(vis);
        minusH.setVisibility(vis);
        plusH.setVisibility(vis);
        remove.setVisibility(vis);
        done.setVisibility(vis);

        if(enabled){
            GradientDrawable bg=new GradientDrawable();
            bg.setColor(0x10000000);
            bg.setStroke(dp(2),0xFFFFFFFF);
            bg.setCornerRadius(dp(8));
            setBackground(bg);
            bringControlsToFront();
        } else {
            setBackgroundColor(Color.TRANSPARENT);
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev){
        switch(ev.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
                downX=ev.getX();
                downY=ev.getY();
                longPressTriggered=false;
                handler.removeCallbacks(longPressRunnable);
                handler.postDelayed(longPressRunnable,520L);
                break;

            case MotionEvent.ACTION_MOVE:
                if(Math.abs(ev.getX()-downX)>touchSlop || Math.abs(ev.getY()-downY)>touchSlop){
                    handler.removeCallbacks(longPressRunnable);
                }
                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacks(longPressRunnable);
                if(longPressTriggered){
                    longPressTriggered=false;
                    return true;
                }
                break;
        }

        // In edit mode, handles/wrapper own interaction. Otherwise let widget behave normally.
        return super.dispatchTouchEvent(ev);
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev){
        // Once editing, prevent the widget content from swallowing resize-handle gestures.
        if(editMode) return false;
        return false;
    }

    private void bringControlsToFront(){
        minusW.bringToFront();
        plusW.bringToFront();
        minusH.bringToFront();
        plusH.bringToFront();
        remove.bringToFront();
        done.bringToFront();
    }

    private void resizeBy(int dx,int dy){
        Integer sxTag=(Integer)getTag(R.id.desktop_span_x);
        Integer syTag=(Integer)getTag(R.id.desktop_span_y);
        int sx=sxTag==null?1:sxTag;
        int sy=syTag==null?1:syTag;

        sx=Math.max(1,Math.min(maxColumns,sx+dx));
        sy=Math.max(1,Math.min(maxRows,sy+dy));

        setTag(R.id.desktop_span_x,sx);
        setTag(R.id.desktop_span_y,sy);

        if(resizeListener!=null) resizeListener.onResize(sx,sy);
    }

    private TextView handle(String text){
        TextView v=new TextView(getContext());
        v.setText(text);
        v.setTextColor(Color.WHITE);
        v.setTextSize(11);
        v.setGravity(Gravity.CENTER);
        v.setClickable(true);
        v.setFocusable(true);

        GradientDrawable bg=new GradientDrawable();
        bg.setColor(0xF0202326);
        bg.setStroke(dp(1),0xFFFFFFFF);
        bg.setCornerRadius(dp(14));
        v.setBackground(bg);
        return v;
    }

    private void addHandle(View v,int gravity){
        LayoutParams lp=new LayoutParams(dp(44),dp(32));
        lp.gravity=gravity;
        lp.setMargins(dp(3),dp(3),dp(3),dp(3));
        addView(v,lp);
    }

    private void addDoneHandle(View v,int unused){
        addDoneHandle(v);
    }

    private void addDoneHandle(View v){
        LayoutParams lp=new LayoutParams(dp(68),dp(34));
        lp.gravity=Gravity.BOTTOM|Gravity.RIGHT;
        lp.setMargins(dp(3),dp(3),dp(6),dp(6));
        addView(v,lp);
    }

    private int dp(float v){
        return Math.round(v*getResources().getDisplayMetrics().density);
    }
}
