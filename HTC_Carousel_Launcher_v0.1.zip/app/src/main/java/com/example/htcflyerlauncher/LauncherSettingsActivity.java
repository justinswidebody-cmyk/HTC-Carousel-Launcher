package com.example.htcflyerlauncher;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Switch;
import java.util.List;

public class LauncherSettingsActivity extends Activity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_settings);

        Spinner spinner=findViewById(R.id.icon_pack_spinner);
        Spinner grid=findViewById(R.id.grid_spinner);
        Switch carousel=findViewById(R.id.carousel_effect);
        String[] grids={"4 × 4","5 × 4 (default)","5 × 5","6 × 4","6 × 5"};
        grid.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, grids));
        int gc=getSharedPreferences("launcher",MODE_PRIVATE).getInt("grid_columns",5);
        int gr=getSharedPreferences("launcher",MODE_PRIVATE).getInt("grid_rows",4);
        int gi=(gc==4&&gr==4)?0:(gc==5&&gr==5)?2:(gc==6&&gr==4)?3:(gc==6&&gr==5)?4:1;
        grid.setSelection(gi);
        IconPackManager manager=new IconPackManager(this);
        List<IconPackManager.Pack> packs=manager.listPacks();
        spinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, packs));

        for(int i=0;i<packs.size();i++){
            if(packs.get(i).packageName.equals(manager.selectedPackage())) {
                spinner.setSelection(i); break;
            }
        }

        carousel.setChecked(getSharedPreferences("launcher",MODE_PRIVATE).getBoolean("carousel_effect",true));

        findViewById(R.id.save).setOnClickListener(v -> {
            IconPackManager.Pack p=(IconPackManager.Pack)spinner.getSelectedItem();
            manager.select(p == null ? "" : p.packageName);
            int[][] dims={{4,4},{5,4},{5,5},{6,4},{6,5}};
            int[] d=dims[Math.max(0,grid.getSelectedItemPosition())];
            getSharedPreferences("launcher",MODE_PRIVATE).edit()
                    .putBoolean("carousel_effect",carousel.isChecked())
                    .putInt("grid_columns",d[0]).putInt("grid_rows",d[1]).apply();
            finish();
        });
    }
}
