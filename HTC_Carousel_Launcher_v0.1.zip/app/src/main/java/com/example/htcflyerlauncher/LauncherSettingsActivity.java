package com.example.htcflyerlauncher;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Switch;
import java.util.List;

public class LauncherSettingsActivity extends Activity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_settings);

        Spinner spinner=findViewById(R.id.icon_pack_spinner);
        Switch carousel=findViewById(R.id.carousel_effect);
        IconPackManager manager=new IconPackManager(this);
        List<IconPackManager.Pack> packs=manager.listPacks();
        spinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, packs));

        for(int i=0;i<packs.size();i++){
            if(packs.get(i).packageName.equals(manager.selectedPackage())) {
                spinner.setSelection(i); break;
            }
        }

        carousel.setChecked(getSharedPreferences("launcher",MODE_PRIVATE).getBoolean("carousel_effect",true));

        findViewById(R.id.save).setOnClickListener(v -> {
            IconPackManager.Pack p=(IconPackManager.Pack)spinner.getSelectedItem();
            manager.select(p == null ? "" : p.packageName);
            getSharedPreferences("launcher",MODE_PRIVATE).edit()
                    .putBoolean("carousel_effect",carousel.isChecked()).apply();
            finish();
        });
    }
}
