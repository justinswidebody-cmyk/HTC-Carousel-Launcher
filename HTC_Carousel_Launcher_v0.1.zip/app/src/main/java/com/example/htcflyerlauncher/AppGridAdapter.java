package com.example.htcflyerlauncher;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.List;

public class AppGridAdapter extends BaseAdapter {
    private final Context context;
    private final List<ResolveInfo> apps;
    private final PackageManager pm;
    private final IconPackManager packs;

    public AppGridAdapter(Context context, List<ResolveInfo> apps, IconPackManager packs) {
        this.context=context; this.apps=apps; this.pm=context.getPackageManager(); this.packs=packs;
    }

    @Override public int getCount(){ return apps.size(); }
    @Override public ResolveInfo getItem(int position){ return apps.get(position); }
    @Override public long getItemId(int position){ return position; }

    @Override public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) convertView = LayoutInflater.from(context).inflate(R.layout.app_cell,parent,false);
        ResolveInfo ri=apps.get(position);
        TextView label=convertView.findViewById(R.id.label);
        ImageView icon=convertView.findViewById(R.id.icon);
        label.setText(ri.loadLabel(pm));
        Drawable fallback=ri.loadIcon(pm);
        icon.setImageDrawable(packs.iconFor(new ComponentName(ri.activityInfo.packageName,ri.activityInfo.name), fallback));
        return convertView;
    }
}
