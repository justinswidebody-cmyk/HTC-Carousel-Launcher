package com.example.htcflyerlauncher;

import android.content.Context;
import android.content.res.Configuration;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;

public class FlyerCarouselView extends HorizontalScrollView {
    public static final int PAGE_COUNT = 8;
    private final LinearLayout strip;
    private final DesktopPageView[] pages = new DesktopPageView[PAGE_COUNT];
    private int currentPage = 3;
    private float downX;
    private boolean carouselEnabled = true;
    private OnPageChangedListener pageChangedListener;

    public interface OnPageChangedListener {
        void onPageChanged(int page);
    }

    public FlyerCarouselView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setFillViewport(true);
        setHorizontalScrollBarEnabled(false);
        setOverScrollMode(OVER_SCROLL_NEVER);
        setClipChildren(false);
        setClipToPadding(false);

        strip = new LinearLayout(context);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        strip.setClipChildren(false);
        strip.setClipToPadding(false);
        addView(strip, new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.MATCH_PARENT));

        for (int i = 0; i < PAGE_COUNT; i++) {
            DesktopPageView page = new DesktopPageView(context);
            page.setPageIndex(i);
            page.setClipChildren(false);
            page.setClipToPadding(false);
            pages[i] = page;
            strip.addView(page, new LinearLayout.LayoutParams(1, LayoutParams.MATCH_PARENT));
        }
    }

    public void setOnPageChangedListener(OnPageChangedListener l) { pageChangedListener = l; }
    public void setCarouselEnabled(boolean enabled) { carouselEnabled = enabled; applyTransforms(); }
    public DesktopPageView getPage(int index) { return pages[Math.max(0, Math.min(PAGE_COUNT - 1, index))]; }
    public DesktopPageView getCurrentPageView() { return getPage(currentPage); }
    public int getCurrentPage() { return currentPage; }

    public void goToPage(int page, boolean smooth) {
        page = Math.max(0, Math.min(PAGE_COUNT - 1, page));
        currentPage = page;
        int x = page * getWidth();
        if (smooth) smoothScrollTo(x, 0); else scrollTo(x, 0);
        notifyPage();
    }

    private void notifyPage() {
        if (pageChangedListener != null) pageChangedListener.onPageChanged(currentPage);
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w <= 0) return;
        for (DesktopPageView page : pages) {
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) page.getLayoutParams();
            lp.width = w;
            lp.height = h;
            page.setLayoutParams(lp);
            page.updateGridForOrientation(
                getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE
            );
        }
        strip.requestLayout();
        post(() -> goToPage(currentPage, false));
    }

    @Override protected void onScrollChanged(int l, int t, int oldl, int oldt) {
        super.onScrollChanged(l, t, oldl, oldt);
        if (getWidth() > 0) {
            int p = Math.max(0, Math.min(PAGE_COUNT - 1, Math.round((float) l / getWidth())));
            if (p != currentPage) {
                currentPage = p;
                notifyPage();
            }
        }
        applyTransforms();
    }

    private void applyTransforms() {
        if (getWidth() <= 0) return;
        float center = getScrollX() + getWidth() / 2f;
        for (DesktopPageView page : pages) {
            float pageCenter = page.getLeft() + page.getWidth() / 2f;
            float delta = (pageCenter - center) / getWidth();
            float abs = Math.min(1f, Math.abs(delta));
            if (carouselEnabled) {
                page.setCameraDistance(getResources().getDisplayMetrics().density * 8000f);
                page.setPivotX(delta < 0 ? page.getWidth() : 0f);
                page.setPivotY(page.getHeight() * .50f);
                page.setRotationY(-delta * 52f);
                float scale = 1f - abs * .12f;
                page.setScaleX(scale);
                page.setScaleY(scale);
                page.setAlpha(1f - abs * .18f);
            } else {
                page.setRotationY(0f);
                page.setScaleX(1f);
                page.setScaleY(1f);
                page.setAlpha(1f);
            }
        }
    }

    @Override public boolean onTouchEvent(MotionEvent ev) {
        if (ev.getActionMasked() == MotionEvent.ACTION_DOWN) downX = ev.getX();
        boolean handled = super.onTouchEvent(ev);
        if (ev.getActionMasked() == MotionEvent.ACTION_UP || ev.getActionMasked() == MotionEvent.ACTION_CANCEL) {
            float dx = ev.getX() - downX;
            int target = getWidth() > 0 ? Math.round((float)getScrollX()/getWidth()) : currentPage;
            if (Math.abs(dx) > getWidth() * .15f) target += dx < 0 ? 1 : -1;
            goToPage(target, true);
        }
        return handled;
    }
}
