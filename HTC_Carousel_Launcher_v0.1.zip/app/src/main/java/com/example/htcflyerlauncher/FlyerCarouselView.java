package com.example.htcflyerlauncher;

import android.content.Context;
import android.content.res.Configuration;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.animation.ValueAnimator;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;

public class FlyerCarouselView extends HorizontalScrollView {
    public static final int PAGE_COUNT = 8;
    private final LinearLayout strip;
    private final DesktopPageView[] pages = new DesktopPageView[PAGE_COUNT];
    private int currentPage = 3;
    private float downX;
    private VelocityTracker velocityTracker;
    private ValueAnimator spinAnimator;
    private boolean carouselEnabled = true;
    private boolean spinning = false;
    private OnPageChangedListener pageChangedListener;

    public interface OnPageChangedListener {
        void onPageChanged(int page);
    }

    public FlyerCarouselView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setFillViewport(true);
        setHorizontalScrollBarEnabled(false);
        setOverScrollMode(OVER_SCROLL_NEVER);
        setClipChildren(false);
        setClipToPadding(false);

        strip = new LinearLayout(context);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        strip.setClipChildren(false);
        strip.setClipToPadding(false);
        addView(strip, new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.MATCH_PARENT));

        for (int i = 0; i < PAGE_COUNT; i++) {
            DesktopPageView page = new DesktopPageView(context);
            page.setPageIndex(i);
            page.setClipChildren(false);
            page.setClipToPadding(false);
            pages[i] = page;
            strip.addView(page, new LinearLayout.LayoutParams(1, LayoutParams.MATCH_PARENT));
        }
    }

    public void setOnPageChangedListener(OnPageChangedListener l) { pageChangedListener = l; }
    public void setCarouselEnabled(boolean enabled) { carouselEnabled = enabled; applyTransforms(); }
    public DesktopPageView getPage(int index) { return pages[Math.max(0, Math.min(PAGE_COUNT - 1, index))]; }
    public DesktopPageView getCurrentPageView() { return getPage(currentPage); }
    public int getCurrentPage() { return currentPage; }

    public void goToPage(int page, boolean smooth) {
        page = Math.max(0, Math.min(PAGE_COUNT - 1, page));
        currentPage = page;
        int x = page * getWidth();
        if (smooth) smoothScrollTo(x, 0); else scrollTo(x, 0);
        notifyPage();
    }

    private void notifyPage() {
        if (pageChangedListener != null) pageChangedListener.onPageChanged(currentPage);
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w <= 0) return;
        for (DesktopPageView page : pages) {
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) page.getLayoutParams();
            lp.width = w;
            lp.height = h;
            page.setLayoutParams(lp);
            page.updateGridForOrientation(
                getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE
            );
        }
        strip.requestLayout();
        post(() -> goToPage(currentPage, false));
    }

    @Override protected void onScrollChanged(int l, int t, int oldl, int oldt) {
        super.onScrollChanged(l, t, oldl, oldt);
        if (getWidth() > 0) {
            int p = Math.max(0, Math.min(PAGE_COUNT - 1, Math.round((float) l / getWidth())));
            if (p != currentPage) {
                currentPage = p;
                notifyPage();
            }
        }
        applyTransforms();
    }

    private void applyTransforms() {
        if (getWidth() <= 0) return;
        float center = getScrollX() + getWidth() / 2f;
        for (DesktopPageView page : pages) {
            float pageCenter = page.getLeft() + page.getWidth() / 2f;
            float delta = (pageCenter - center) / getWidth();
            float abs = Math.min(1f, Math.abs(delta));
            if (carouselEnabled) {
                page.setCameraDistance(getResources().getDisplayMetrics().density * 10500f);
                page.setPivotX(delta < 0 ? page.getWidth() : 0f);
                page.setPivotY(page.getHeight() * .50f);
                page.setRotationY(delta * 58f);
                float scale = 1f - abs * .16f;
                page.setScaleX(scale);
                page.setScaleY(scale);
                page.setAlpha(1f - abs * .18f);
            } else {
                page.setRotationY(0f);
                page.setScaleX(1f);
                page.setScaleY(1f);
                page.setAlpha(1f);
            }
        }
    }

    @Override public boolean onTouchEvent(MotionEvent ev) {
        if (velocityTracker == null) velocityTracker = VelocityTracker.obtain();
        velocityTracker.addMovement(ev);

        if (ev.getActionMasked() == MotionEvent.ACTION_DOWN) {
            downX = ev.getX();
            if (spinAnimator != null) spinAnimator.cancel();
            spinning = false;
        }

        boolean handled = super.onTouchEvent(ev);

        if (ev.getActionMasked() == MotionEvent.ACTION_UP ||
                ev.getActionMasked() == MotionEvent.ACTION_CANCEL) {

            velocityTracker.computeCurrentVelocity(1000);
            float velocityX = velocityTracker.getXVelocity();
            float dx = ev.getX() - downX;

            if (ev.getActionMasked() == MotionEvent.ACTION_UP &&
                    Math.abs(velocityX) > 1250f) {
                // A hard swipe behaves like the old Sense "spin the carousel"
                // gesture. Faster flings carry through more screens.
                int pagesToTravel = 2 + Math.min(5, (int)(Math.abs(velocityX) / 1800f));
                int direction = velocityX < 0 ? 1 : -1;
                spinAcrossPages(direction, pagesToTravel, Math.abs(velocityX));
            } else {
                int target = getWidth() > 0
                        ? Math.round((float)getScrollX() / getWidth())
                        : currentPage;
                if (Math.abs(dx) > getWidth() * .15f) target += dx < 0 ? 1 : -1;
                goToPage(target, true);
            }

            velocityTracker.recycle();
            velocityTracker = null;
        }
        return handled;
    }

    private void spinAcrossPages(int direction, int requestedPages, float velocity) {
        if (getWidth() <= 0) return;

        // We keep the physical strip finite but let a hard spin coast across as
        // many available screens as momentum allows.
        int edgeDistance = direction > 0
                ? (PAGE_COUNT - 1 - currentPage)
                : currentPage;
        int pages = Math.max(1, Math.min(requestedPages, edgeDistance));
        if (pages <= 0) {
            goToPage(currentPage, true);
            return;
        }

        final int startX = getScrollX();
        final int targetPage = currentPage + direction * pages;
        final int targetX = targetPage * getWidth();

        long duration = Math.max(420L,
                Math.min(1050L, 880L - (long)Math.min(420f, velocity / 8f) + pages * 80L));

        spinning = true;
        spinAnimator = ValueAnimator.ofInt(startX, targetX);
        spinAnimator.setDuration(duration);
        spinAnimator.setInterpolator(new DecelerateInterpolator(1.35f));
        spinAnimator.addUpdateListener(a -> {
            int x = (Integer)a.getAnimatedValue();
            scrollTo(x, 0);
            // onScrollChanged continuously applies the 3D outside-facing
            // perspective, making the whole row appear to spin as one carousel.
        });
        spinAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator animation) {
                spinning = false;
                currentPage = targetPage;
                notifyPage();
                applyTransforms();
            }

            @Override public void onAnimationCancel(android.animation.Animator animation) {
                spinning = false;
            }
        });
        spinAnimator.start();
    }
}
