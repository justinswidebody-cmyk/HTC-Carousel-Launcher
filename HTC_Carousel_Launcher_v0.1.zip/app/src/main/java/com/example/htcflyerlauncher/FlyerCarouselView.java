package com.example.htcflyerlauncher;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Configuration;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;

public class FlyerCarouselView extends FrameLayout {
    public static final int PAGE_COUNT = 8;

    private final DesktopPageView[] pages = new DesktopPageView[PAGE_COUNT];
    private OnPageChangedListener pageChangedListener;

    // Continuous carousel position. Integer values always mean a page is perfectly centered.
    // It may move beyond 0..7 while spinning; transforms wrap it back around the 8-page ring.
    private float position = 3f;
    private int currentPage = 3;

    private float downX;
    private float lastX;
    private boolean dragging = false;
    private boolean carouselEnabled = true;
    private final int touchSlop;

    private VelocityTracker velocityTracker;
    private ValueAnimator animator;
    private boolean senseSpinMode = false;

    public interface OnPageChangedListener {
        void onPageChanged(int page);
    }

    public FlyerCarouselView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setClipChildren(false);
        setClipToPadding(false);
        setMotionEventSplittingEnabled(false);
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();

        for (int i = 0; i < PAGE_COUNT; i++) {
            DesktopPageView page = new DesktopPageView(context);
            page.setPageIndex(i);
            page.setClipChildren(false);
            page.setClipToPadding(false);
            pages[i] = page;
            addView(page, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        }

        post(this::applyTransforms);
    }

    public void setOnPageChangedListener(OnPageChangedListener l) {
        pageChangedListener = l;
    }

    public void setCarouselEnabled(boolean enabled) {
        carouselEnabled = enabled;
        applyTransforms();
    }

    public DesktopPageView getPage(int index) {
        return pages[mod(index, PAGE_COUNT)];
    }

    public DesktopPageView getCurrentPageView() {
        return pages[currentPage];
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public void goToPage(int page, boolean smooth) {
        page = mod(page, PAGE_COUNT);
        float delta = shortestDelta(currentPage, page);
        float target = position + delta;

        if (!smooth || getWidth() == 0) {
            position = target;
            finishAtNearestPage();
        } else {
            animateTo(target, 320L);
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        // Do not remap the desktop grid merely because the host view changed size.
        // LauncherActivity applies the destination orientation atomically while hidden.
        post(this::applyTransforms);
    }

    public void applyOrientationMode(int orientation) {
        boolean landscape = orientation == Configuration.ORIENTATION_LANDSCAPE;
        for (DesktopPageView page : pages) {
            page.updateGridForOrientation(landscape);
        }
        requestLayout();
        applyTransforms();
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        final int action = ev.getActionMasked();

        if (action == MotionEvent.ACTION_DOWN) {
            downX = lastX = ev.getX();
            dragging = false;
            stopAnimation();
            ensureVelocityTracker();
            velocityTracker.addMovement(ev);
            return false;
        }

        if (action == MotionEvent.ACTION_MOVE) {
            ensureVelocityTracker();
            velocityTracker.addMovement(ev);
            float dx = ev.getX() - downX;
            if (Math.abs(dx) > touchSlop) {
                dragging = true;
                lastX = ev.getX();
                getParent().requestDisallowInterceptTouchEvent(true);
                return true;
            }
        }

        return dragging;
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        ensureVelocityTracker();
        velocityTracker.addMovement(ev);

        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = lastX = ev.getX();
                dragging = false;
                stopAnimation();
                return true;

            case MotionEvent.ACTION_MOVE:
                float x = ev.getX();
                float dx = x - lastX;
                if (!dragging && Math.abs(x - downX) > touchSlop) dragging = true;
                if (dragging && getWidth() > 0) {
                    // Finger left => carousel advances to next logical screen.
                    position -= dx / (getWidth() * 0.78f);
                    lastX = x;
                    updateCurrentFromPosition();
                    applyTransforms();
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                velocityTracker.computeCurrentVelocity(1000);
                float vx = velocityTracker.getXVelocity();
                recycleVelocityTracker();

                if (!dragging || ev.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                    snapToNearestPage();
                    dragging = false;
                    return true;
                }

                dragging = false;

                // Deliberately require a substantial fling before "Sense top spin" engages.
                // Normal swipes move one page. Hard flings coast through several pages.
                if (Math.abs(vx) >= 2400f) {
                    int direction = vx < 0 ? 1 : -1;
                    int extraPages = 2 + Math.min(6, (int)(Math.abs(vx) / 2300f));
                    float target = Math.round(position) + direction * extraPages;
                    long duration = 720L + Math.min(900L, extraPages * 120L);
                    startSenseSpin(target, duration);
                } else {
                    float travel = ev.getX() - downX;
                    float target = Math.round(position);
                    // Lower sensitivity: a deliberate swipe must cover ~28% of the screen.
                    if (Math.abs(travel) > getWidth() * 0.28f) {
                        target = Math.round(position + (travel < 0 ? 0.55f : -0.55f));
                    }
                    animateTo(target, 300L);
                }
                return true;
        }
        return true;
    }

    private void startSenseSpin(float target, long duration) {
        stopAnimation();
        senseSpinMode = true;

        // Old Sense "top spin": the whole desktop pulls away from the viewer
        // before the ring accelerates, exposing multiple 3D home-screen faces.
        animate()
                .scaleX(.74f)
                .scaleY(.74f)
                .translationY(-getHeight() * .035f)
                .setDuration(170L)
                .withEndAction(() -> animateSpinPosition(target, duration))
                .start();
    }

    private void animateSpinPosition(float target, long duration) {
        final float start = position;
        animator = ValueAnimator.ofFloat(start, target);
        animator.setDuration(duration);
        animator.setInterpolator(new DecelerateInterpolator(.82f));
        animator.addUpdateListener(a -> {
            position = (Float)a.getAnimatedValue();
            updateCurrentFromPosition();
            applyTransforms();
        });
        animator.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator animation) {
                position = Math.round(position);
                currentPage = mod(Math.round(position), PAGE_COUNT);
                position = currentPage;
                applyTransforms();

                // Expand the selected screen back toward the viewer only after
                // the spinning ring has landed squarely on a page.
                animate()
                        .scaleX(1f)
                        .scaleY(1f)
                        .translationY(0f)
                        .setDuration(230L)
                        .withEndAction(() -> {
                            senseSpinMode = false;
                            applyTransforms();
                            notifyPage();
                        })
                        .start();
            }

            @Override public void onAnimationCancel(Animator animation) {
                senseSpinMode = false;
                setScaleX(1f);
                setScaleY(1f);
                setTranslationY(0f);
                position = Math.round(position);
                finishAtNearestPage();
            }
        });
        animator.start();
    }

    private void snapToNearestPage() {
        animateTo(Math.round(position), 260L);
    }

    private void animateTo(float target, long duration) {
        stopAnimation();

        final float start = position;
        animator = ValueAnimator.ofFloat(start, target);
        animator.setDuration(duration);
        animator.setInterpolator(new DecelerateInterpolator(1.25f));
        animator.addUpdateListener(a -> {
            position = (Float) a.getAnimatedValue();
            updateCurrentFromPosition();
            applyTransforms();
        });
        animator.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator animation) {
                finishAtNearestPage();
            }

            @Override public void onAnimationCancel(Animator animation) {
                // Even interrupted spins must never leave the carousel between screens.
                position = Math.round(position);
                finishAtNearestPage();
            }
        });
        animator.start();
    }

    private void finishAtNearestPage() {
        position = Math.round(position);
        currentPage = mod(Math.round(position), PAGE_COUNT);

        // Keep the floating coordinate small while preserving the same logical screen.
        position = currentPage;

        applyTransforms();
        notifyPage();
    }

    private void updateCurrentFromPosition() {
        int newPage = mod(Math.round(position), PAGE_COUNT);
        if (newPage != currentPage) {
            currentPage = newPage;
            notifyPage();
        }
    }

    private void applyTransforms() {
        if (getWidth() <= 0 || getHeight() <= 0) return;

        final float width = getWidth();

        for (int i = 0; i < PAGE_COUNT; i++) {
            DesktopPageView page = pages[i];

            // Signed shortest distance around the circular ring.
            float delta = circularDelta(i, position);
            float abs = Math.abs(delta);

            if (!carouselEnabled) {
                page.setRotationY(0f);
                page.setScaleX(1f);
                page.setScaleY(1f);
                page.setTranslationX(delta * width);
                page.setTranslationZ(0f);
                page.setAlpha(abs < 0.55f ? 1f : 0f);
                page.setVisibility(abs < 1.1f ? VISIBLE : INVISIBLE);
                continue;
            }

            // A normal swipe exposes only neighboring faces. During a hard Sense
            // fling we deliberately reveal most of the ring so it reads as a 3D carousel.
            boolean visible = abs <= (senseSpinMode ? 3.65f : 1.65f);
            page.setVisibility(visible ? VISIBLE : INVISIBLE);
            if (!visible) continue;

            page.setCameraDistance(getResources().getDisplayMetrics().density *
                    (senseSpinMode ? 15000f : 12000f));
            page.setPivotX(width / 2f);
            page.setPivotY(getHeight() * 0.50f);

            if (senseSpinMode) {
                // Pulled-back connected ring. Pages occupy a tighter horizontal arc,
                // with stronger perspective so you can watch the carousel spin.
                page.setTranslationX(delta * width * .34f);
                page.setRotationY(delta * 43f);
                float scale = .90f - Math.min(.30f, abs * .085f);
                page.setScaleX(scale);
                page.setScaleY(scale);
                page.setTranslationZ(-Math.min(220f, abs * 72f));
                page.setAlpha(1f - Math.min(.62f, abs * .16f));
            } else {
                // OUTSIDE-facing normal page turn.
                page.setTranslationX(delta * width * .72f);
                page.setRotationY(delta * 56f);
                float scale = 1f - Math.min(.17f, abs * .13f);
                page.setScaleX(scale);
                page.setScaleY(scale);
                page.setTranslationZ((1f - Math.min(1f, abs)) * 22f);
                page.setAlpha(1f - Math.min(.55f, abs * .30f));
            }
        }

        // The centered logical page should receive taps above the side faces.
        pages[currentPage].bringToFront();
        invalidate();
    }

    private float circularDelta(int pageIndex, float continuousPosition) {
        float logical = continuousPosition % PAGE_COUNT;
        if (logical < 0) logical += PAGE_COUNT;

        float d = pageIndex - logical;
        while (d > PAGE_COUNT / 2f) d -= PAGE_COUNT;
        while (d < -PAGE_COUNT / 2f) d += PAGE_COUNT;
        return d;
    }

    private float shortestDelta(int from, int to) {
        int d = to - from;
        if (d > PAGE_COUNT / 2) d -= PAGE_COUNT;
        if (d < -PAGE_COUNT / 2) d += PAGE_COUNT;
        return d;
    }

    private void notifyPage() {
        if (pageChangedListener != null) pageChangedListener.onPageChanged(currentPage);
    }

    private void stopAnimation() {
        animate().cancel();
        if (animator != null) {
            ValueAnimator a = animator;
            animator = null;
            a.cancel();
        }
        if (senseSpinMode) {
            senseSpinMode = false;
            setScaleX(1f);
            setScaleY(1f);
            setTranslationY(0f);
            applyTransforms();
        }
    }

    private void ensureVelocityTracker() {
        if (velocityTracker == null) velocityTracker = VelocityTracker.obtain();
    }

    private void recycleVelocityTracker() {
        if (velocityTracker != null) {
            velocityTracker.recycle();
            velocityTracker = null;
        }
    }

    private static int mod(int value, int modulus) {
        int r = value % modulus;
        return r < 0 ? r + modulus : r;
    }
}
