package com.example.htcflyerlauncher;

import android.app.*;
import android.appwidget.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class LauncherActivity extends Activity {
    private static final int HOST_ID = 0x464C5952;
    private static final int REQ_PICK_WIDGET = 1001;
    private static final int REQ_CONFIG_WIDGET = 1002;
    private static final int REQ_WALLPAPER = 1003;

    private FlyerCarouselView carousel;
    private LinearLayout pageDots;
    private FrameLayout drawer;
    private GridView appGrid;
    private ImageView wallpaperImage;
    private IconPackManager iconPacks;
    private List<ResolveInfo> apps = new ArrayList<>();

    private AppWidgetHost widgetHost;
    private AppWidgetManager widgetManager;
    private int pendingWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private int pendingPage = 3;
    private boolean desktopEditMode = false;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);

        setContentView(R.layout.activity_launcher);

        carousel = findViewById(R.id.carousel);
        pageDots = findViewById(R.id.page_dots);
        drawer = findViewById(R.id.drawer);
        appGrid = findViewById(R.id.app_grid);
        wallpaperImage = findViewById(R.id.wallpaper_image);

        widgetManager = AppWidgetManager.getInstance(this);
        widgetHost = new AppWidgetHost(this, HOST_ID);
        iconPacks = new IconPackManager(this);

        for (int i=0;i<FlyerCarouselView.PAGE_COUNT;i++) {
            final int page=i;
            carousel.getPage(i).setOnReorderListener((p,from,to) -> saveShortcutOrder(page));
        }

        carousel.setOnPageChangedListener(page -> {
            updateDots(page);
            getSharedPreferences("launcher",MODE_PRIVATE).edit().putInt("current_page",page).apply();
        });

        findViewById(R.id.apps).setOnClickListener(v -> toggleDrawer());
        findViewById(R.id.add_widget).setOnClickListener(v -> pickWidget());
        findViewById(R.id.settings).setOnClickListener(v ->
                startActivity(new Intent(this,LauncherSettingsActivity.class)));
        findViewById(R.id.personalize).setOnClickListener(v -> toggleDesktopEditMode());

        carousel.setOnLongClickListener(v -> {
            setDesktopEditMode(true);
            Toast.makeText(this,"Edit mode: drag items and resize widgets",Toast.LENGTH_SHORT).show();
            return true;
        });

        setupDots();
        loadWallpaper();
        loadShortcuts();
        restoreWidgets();
        setupApps();

        int startPage=getSharedPreferences("launcher",MODE_PRIVATE).getInt("current_page",3);
        carousel.post(() -> carousel.goToPage(startPage,false));
    }

    @Override protected void onStart() {
        super.onStart();
        try { widgetHost.startListening(); } catch(Throwable ignored) {}
    }

    @Override protected void onStop() {
        super.onStop();
        try { widgetHost.stopListening(); } catch(Throwable ignored) {}
    }

    @Override protected void onResume() {
        super.onResume();
        carousel.setCarouselEnabled(getSharedPreferences("launcher",MODE_PRIVATE)
                .getBoolean("carousel_effect",true));
        iconPacks = new IconPackManager(this);
        setupApps();
        refreshShortcutIcons();
        loadWallpaper();
    }

    private void setupDots() {
        pageDots.removeAllViews();
        for(int i=0;i<FlyerCarouselView.PAGE_COUNT;i++) {
            View dot=new View(this);
            int size=dp(7);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(size,size);
            lp.setMargins(dp(4),0,dp(4),0);
            dot.setLayoutParams(lp);
            dot.setBackgroundResource(R.drawable.flyer_page_hint);
            pageDots.addView(dot);
        }
        updateDots(3);
    }

    private void updateDots(int selected) {
        for(int i=0;i<pageDots.getChildCount();i++) {
            View d=pageDots.getChildAt(i);
            d.setAlpha(i==selected?1f:.28f);
            d.setScaleX(i==selected?1.35f:1f);
            d.setScaleY(i==selected?1.35f:1f);
        }
    }

    private void loadWallpaper() {
        if (wallpaperImage == null) return;
        wallpaperImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        boolean useSystem = getSharedPreferences("launcher", MODE_PRIVATE)
                .getBoolean("use_system_wallpaper", false);
        if (useSystem) {
            try {
                android.graphics.drawable.Drawable d = WallpaperManager.getInstance(this).getDrawable();
                if (d != null) {
                    wallpaperImage.setImageDrawable(d);
                    return;
                }
            } catch (Throwable ignored) {}
        }
        wallpaperImage.setImageResource(R.drawable.default_wallpaper);
    }

    private void setupApps() {
        Intent query=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        apps=getPackageManager().queryIntentActivities(query,0);
        apps.sort(Comparator.comparing(a -> String.valueOf(a.loadLabel(getPackageManager())), String.CASE_INSENSITIVE_ORDER));

        appGrid.setAdapter(new AppGridAdapter(this,apps,iconPacks));
        appGrid.setOnItemClickListener((parent,view,pos,id) -> {
            launchResolveInfo(apps.get(pos));
            drawer.setVisibility(View.GONE);
        });
        appGrid.setOnItemLongClickListener((parent,view,pos,id) -> {
            ResolveInfo ri=apps.get(pos);
            addShortcutToPage(ri, carousel.getCurrentPage(), true);
            drawer.setVisibility(View.GONE);
            Toast.makeText(this,"Added to home screen "+(carousel.getCurrentPage()+1),Toast.LENGTH_SHORT).show();
            return true;
        });
    }

    private void toggleDrawer() {
        drawer.setVisibility(drawer.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE);
    }

    private void launchResolveInfo(ResolveInfo ri) {
        Intent launch=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(new ComponentName(ri.activityInfo.packageName,ri.activityInfo.name))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        try { startActivity(launch); } catch(Throwable ignored) {}
    }

    private View createShortcutView(ComponentName component, String label, int slot, int page) {
        View v=getLayoutInflater().inflate(R.layout.shortcut_cell,null,false);
        ImageView icon=v.findViewById(R.id.icon);
        TextView text=v.findViewById(R.id.label);
        text.setText(label);
        v.setTag(R.id.desktop_component,component.flattenToString());
        v.setTag(R.id.desktop_slot,slot);

        try {
            ActivityInfo ai=getPackageManager().getActivityInfo(component,0);
            icon.setImageDrawable(iconPacks.iconFor(component,ai.loadIcon(getPackageManager())));
        } catch(Throwable ignored) {}

        v.setOnClickListener(view -> {
            try {
                Intent i=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                        .setComponent(component)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                startActivity(i);
            } catch(Throwable ignored) {}
        });

        // DesktopPageView installs long-press drag behavior when this child is added.
        return v;
    }

    private void addShortcutToPage(ResolveInfo ri, int page, boolean persist) {
        DesktopPageView desktop=carousel.getPage(page);
        int slot=desktop.nextFreeSlot();
        if(slot<0) {
            Toast.makeText(this,"This home screen is full",Toast.LENGTH_SHORT).show();
            return;
        }
        ComponentName component=new ComponentName(ri.activityInfo.packageName,ri.activityInfo.name);
        String label=String.valueOf(ri.loadLabel(getPackageManager()));
        View shortcut=createShortcutView(component,label,slot,page);
        desktop.addDesktopItem(shortcut,slot);
        if(persist) saveShortcuts(page);
    }

    private void loadShortcuts() {
        for(int page=0;page<FlyerCarouselView.PAGE_COUNT;page++) {
            String data=getSharedPreferences("launcher",MODE_PRIVATE).getString("shortcuts_"+page,"");
            if(data==null||data.isEmpty()) continue;
            for(String line:data.split("\n")) {
                String[] parts=line.split("\\|",3);
                if(parts.length<3) continue;
                try {
                    int slot=Integer.parseInt(parts[0]);
                    ComponentName component=ComponentName.unflattenFromString(parts[1]);
                    String label=parts[2].replace("\\n","\n");
                    if(component==null) continue;
                    // Skip removed apps.
                    getPackageManager().getActivityInfo(component,0);
                    View shortcut=createShortcutView(component,label,slot,page);
                    carousel.getPage(page).addDesktopItem(shortcut,slot);
                } catch(Throwable ignored) {}
            }
        }
    }

    private void saveShortcuts(int page) {
        DesktopPageView desktop=carousel.getPage(page);
        StringBuilder b=new StringBuilder();
        for(int i=0;i<desktop.getChildCount();i++) {
            View child=desktop.getChildAt(i);
            Object comp=child.getTag(R.id.desktop_component);
            Object slot=child.getTag(R.id.desktop_slot);
            if(!(comp instanceof String) || !(slot instanceof Integer)) continue;
            TextView label=child.findViewById(R.id.label);
            if(b.length()>0)b.append("\n");
            b.append(slot).append("|").append(comp).append("|")
                    .append(label==null?"":label.getText().toString().replace("\n","\\n"));
        }
        getSharedPreferences("launcher",MODE_PRIVATE).edit()
                .putString("shortcuts_"+page,b.toString()).apply();
    }

    private void saveShortcutOrder(int page) { saveShortcuts(page); }

    private void refreshShortcutIcons() {
        for(int page=0;page<FlyerCarouselView.PAGE_COUNT;page++) {
            DesktopPageView desktop=carousel.getPage(page);
            for(int i=0;i<desktop.getChildCount();i++) {
                View child=desktop.getChildAt(i);
                Object c=child.getTag(R.id.desktop_component);
                if(!(c instanceof String)) continue;
                ComponentName cn=ComponentName.unflattenFromString((String)c);
                if(cn==null) continue;
                try {
                    ActivityInfo ai=getPackageManager().getActivityInfo(cn,0);
                    ImageView icon=child.findViewById(R.id.icon);
                    if(icon!=null) icon.setImageDrawable(iconPacks.iconFor(cn,ai.loadIcon(getPackageManager())));
                } catch(Throwable ignored){}
            }
        }
    }


    private void toggleDesktopEditMode() {
        setDesktopEditMode(!desktopEditMode);
        Toast.makeText(this,
                desktopEditMode ? "Edit mode on" : "Edit mode off",
                Toast.LENGTH_SHORT).show();
    }

    private void setDesktopEditMode(boolean enabled) {
        desktopEditMode = enabled;
        for (int i=0;i<FlyerCarouselView.PAGE_COUNT;i++) {
            DesktopPageView page=carousel.getPage(i);
            page.setEditMode(enabled);
            for (int j=0;j<page.getChildCount();j++) {
                View child=page.getChildAt(j);
                if (child instanceof WidgetFrame) {
                    ((WidgetFrame)child).setGridLimits(page.getDesktopColumns(),page.getDesktopRows());
                    ((WidgetFrame)child).setEditMode(enabled);
                }
            }
        }
    }

    private void showLeapOverview() {
        LinearLayout grid=new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        grid.setPadding(dp(12),dp(12),dp(12),dp(12));

        for(int r=0;r<2;r++) {
            LinearLayout row=new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for(int c=0;c<4;c++) {
                int page=r*4+c;
                Button b=new Button(this);
                b.setText(page==3 ? "Home\n"+(page+1) : "Screen\n"+(page+1));
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(92),1f);
                lp.setMargins(dp(4),dp(4),dp(4),dp(4));
                b.setLayoutParams(lp);
                b.setOnClickListener(v -> {
                    carousel.goToPage(page,true);
                    Object tag=grid.getTag();
                    if(tag instanceof AlertDialog) ((AlertDialog)tag).dismiss();
                });
                row.addView(b);
            }
            grid.addView(row);
        }

        AlertDialog dialog=new AlertDialog.Builder(this)
                .setTitle("Leap view")
                .setView(grid)
                .setNeutralButton("Wallpaper",(d,w) -> {
                    try {
                        startActivityForResult(new Intent(Intent.ACTION_SET_WALLPAPER),REQ_WALLPAPER);
                    } catch(Throwable ignored){}
                })
                .setNegativeButton("Close",null)
                .create();
        grid.setTag(dialog);
        dialog.show();
    }

    private void pickWidget() {
        pendingPage=carousel.getCurrentPage();
        pendingWidgetId=widgetHost.allocateAppWidgetId();

        Intent pick=new Intent(AppWidgetManager.ACTION_APPWIDGET_PICK);
        pick.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,pendingWidgetId);
        try {
            startActivityForResult(pick,REQ_PICK_WIDGET);
        } catch(Throwable e) {
            try { widgetHost.deleteAppWidgetId(pendingWidgetId); } catch(Throwable ignored){}
            pendingWidgetId=AppWidgetManager.INVALID_APPWIDGET_ID;
            Toast.makeText(this,"Widget picker is not available on this device",Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);

        if(requestCode==REQ_WALLPAPER) {
            if (resultCode == RESULT_OK) {
                getSharedPreferences("launcher", MODE_PRIVATE).edit()
                        .putBoolean("use_system_wallpaper", true).apply();
            }
            loadWallpaper();
            return;
        }

        if(requestCode!=REQ_PICK_WIDGET && requestCode!=REQ_CONFIG_WIDGET) return;

        int id=data!=null
                ? data.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,pendingWidgetId)
                : pendingWidgetId;

        if(resultCode!=RESULT_OK || id==AppWidgetManager.INVALID_APPWIDGET_ID) {
            if(id!=AppWidgetManager.INVALID_APPWIDGET_ID) {
                try { widgetHost.deleteAppWidgetId(id); } catch(Throwable ignored){}
            }
            pendingWidgetId=AppWidgetManager.INVALID_APPWIDGET_ID;
            return;
        }

        if(requestCode==REQ_PICK_WIDGET) {
            AppWidgetProviderInfo info=widgetManager.getAppWidgetInfo(id);
            if(info!=null && info.configure!=null) {
                Intent cfg=new Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE);
                cfg.setComponent(info.configure);
                cfg.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id);
                try {
                    startActivityForResult(cfg,REQ_CONFIG_WIDGET);
                    return;
                } catch(Throwable ignored) {}
            }
        }
        addWidget(id,pendingPage,true);
    }

    private void addWidget(int id,int page,boolean persist) {
        AppWidgetProviderInfo info=widgetManager.getAppWidgetInfo(id);
        if(info==null) {
            Toast.makeText(this,"Widget could not be bound",Toast.LENGTH_LONG).show();
            return;
        }

        DesktopPageView desktop=carousel.getPage(page);
        int slot=desktop.nextFreeSlot();
        if(slot<0) {
            Toast.makeText(this,"This home screen is full",Toast.LENGTH_SHORT).show();
            return;
        }

        AppWidgetHostView host=widgetHost.createView(this,id,info);
        host.setAppWidget(id,info);
        host.setPadding(0,0,0,0);

        WidgetFrame frame=new WidgetFrame(this,host);
        frame.setTag(R.id.desktop_slot,slot);
        frame.setTag(R.id.desktop_span_x,2);
        frame.setTag(R.id.desktop_span_y,1);
        frame.setGridLimits(desktop.getDesktopColumns(),desktop.getDesktopRows());

        final int widgetId=id;
        final int widgetPage=page;
        frame.setResizeListener(new WidgetFrame.ResizeListener() {
            @Override public void onResize(int spanX,int spanY) {
                desktop.refreshLayout();
                updateWidgetHostSize(host,desktop,spanX,spanY);
                updateWidgetRecord(widgetId,widgetPage,slot,spanX,spanY);
            }

            @Override public void onRemove() {
                desktop.removeView(frame);
                try { widgetHost.deleteAppWidgetId(widgetId); } catch(Throwable ignored) {}
                removeWidgetRecord(widgetId);
            }
        });

        desktop.addDesktopItem(frame,slot);
        frame.setEditMode(desktopEditMode);
        updateWidgetHostSize(host,desktop,2,1);

        if(persist) saveWidgetRecord(id,page,slot,2,1);
        pendingWidgetId=AppWidgetManager.INVALID_APPWIDGET_ID;
    }

    private void updateWidgetHostSize(AppWidgetHostView host, DesktopPageView desktop, int spanX, int spanY) {
        host.post(() -> {
            try {
                float density=getResources().getDisplayMetrics().density;
                int cols=Math.max(1,desktop.getDesktopColumns());
                int rows=Math.max(1,desktop.getDesktopRows());
                int widthDp=Math.max(40,Math.round((desktop.getWidth()/(float)cols)*spanX/density));
                int heightDp=Math.max(40,Math.round((desktop.getHeight()/(float)rows)*spanY/density));
                android.os.Bundle options=new android.os.Bundle();
                host.updateAppWidgetSize(options,widthDp,heightDp,widthDp,heightDp);
            } catch(Throwable ignored) {}
        });
    }

    private void removeWidgetRecord(int widgetId) {
        String data=getSharedPreferences("launcher",MODE_PRIVATE).getString("widgets","");
        if(data==null||data.isEmpty()) return;
        StringBuilder out=new StringBuilder();
        for(String line:data.split("\\n")) {
            String[] p=line.split("\\\\|");
            if(p.length<1) continue;
            try {
                if(Integer.parseInt(p[0])==widgetId) continue;
            } catch(Throwable ignored) {}
            if(out.length()>0) out.append("\\n");
            out.append(line);
        }
        getSharedPreferences("launcher",MODE_PRIVATE).edit().putString("widgets",out.toString()).apply();
    }

    private void updateWidgetRecord(int widgetId,int page,int slot,int spanX,int spanY) {
        String data=getSharedPreferences("launcher",MODE_PRIVATE).getString("widgets","");
        StringBuilder out=new StringBuilder();
        if(data!=null && !data.isEmpty()) {
            for(String line:data.split("\\n")) {
                String[] p=line.split("\\\\|");
                if(p.length<1) continue;
                try {
                    if(Integer.parseInt(p[0])==widgetId) continue;
                } catch(Throwable ignored) {}
                if(out.length()>0) out.append("\\n");
                out.append(line);
            }
        }
        if(out.length()>0) out.append("\\n");
        out.append(widgetId).append("|").append(page).append("|").append(slot)
                .append("|").append(spanX).append("|").append(spanY);
        getSharedPreferences("launcher",MODE_PRIVATE).edit().putString("widgets",out.toString()).apply();
    }

    private void saveWidgetRecord(int id,int page,int slot,int spanX,int spanY) {
        String data=getSharedPreferences("launcher",MODE_PRIVATE).getString("widgets","");
        String rec=id+"|"+page+"|"+slot+"|"+spanX+"|"+spanY;
        if(data==null||data.isEmpty()) data=rec; else data=data+"\n"+rec;
        getSharedPreferences("launcher",MODE_PRIVATE).edit().putString("widgets",data).apply();
    }

    private void restoreWidgets() {
        String data=getSharedPreferences("launcher",MODE_PRIVATE).getString("widgets","");
        if(data==null||data.isEmpty()) return;

        for(String line:data.split("\n")) {
            String[] p=line.split("\\|");
            if(p.length<5) continue;
            try {
                int id=Integer.parseInt(p[0]);
                int page=Integer.parseInt(p[1]);
                int slot=Integer.parseInt(p[2]);
                int spanX=Integer.parseInt(p[3]);
                int spanY=Integer.parseInt(p[4]);

                AppWidgetProviderInfo info=widgetManager.getAppWidgetInfo(id);
                if(info==null) continue;

                DesktopPageView desktop=carousel.getPage(page);
                AppWidgetHostView host=widgetHost.createView(this,id,info);
                host.setAppWidget(id,info);
                host.setPadding(0,0,0,0);

                WidgetFrame frame=new WidgetFrame(this,host);
                frame.setTag(R.id.desktop_slot,slot);
                frame.setTag(R.id.desktop_span_x,spanX);
                frame.setTag(R.id.desktop_span_y,spanY);
                frame.setGridLimits(desktop.getDesktopColumns(),desktop.getDesktopRows());

                final int widgetId=id;
                final int widgetPage=page;
                final int widgetSlot=slot;
                frame.setResizeListener(new WidgetFrame.ResizeListener() {
                    @Override public void onResize(int sx,int sy) {
                        desktop.refreshLayout();
                        updateWidgetHostSize(host,desktop,sx,sy);
                        updateWidgetRecord(widgetId,widgetPage,widgetSlot,sx,sy);
                    }
                    @Override public void onRemove() {
                        desktop.removeView(frame);
                        try { widgetHost.deleteAppWidgetId(widgetId); } catch(Throwable ignored) {}
                        removeWidgetRecord(widgetId);
                    }
                });

                desktop.addDesktopItem(frame,slot);
                frame.setEditMode(desktopEditMode);
                updateWidgetHostSize(host,desktop,spanX,spanY);
            } catch(Throwable ignored){}
        }
    }

    @Override public void onBackPressed() {
        if(desktopEditMode) {
            setDesktopEditMode(false);
            return;
        }
        if(drawer.getVisibility()==View.VISIBLE) {
            drawer.setVisibility(View.GONE);
            return;
        }
        carousel.goToPage(3,true);
    }

    @Override public void onConfigurationChanged(android.content.res.Configuration newConfig) {
        int page=carousel.getCurrentPage();
        super.onConfigurationChanged(newConfig);
        carousel.post(() -> carousel.goToPage(page,false));
    }

    private int dp(float value) {
        return Math.round(value*getResources().getDisplayMetrics().density);
    }
}
