package com.example.htcflyerlauncher;

import android.content.ClipData;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.View;
import android.widget.GridLayout;
import android.widget.TextView;

public class DesktopPageView extends GridLayout {
    private int pageIndex;
    private int columns = 4;
    private int rows = 4;
    private OnReorderListener reorderListener;
    private final Paint pagePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public interface OnReorderListener {
        void onReorder(int page, int from, int to);
    }

    public DesktopPageView(Context context) {
        super(context);
        setUseDefaultMargins(false);
        setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        setPadding(dp(14), dp(34), dp(14), dp(18));
        setBackgroundColor(Color.TRANSPARENT);
        setWillNotDraw(false);
        pagePaint.setStyle(Paint.Style.STROKE);
        pagePaint.setStrokeWidth(dp(1));
        pagePaint.setColor(0x55FFFFFF);
        textPaint.setColor(0xCCFFFFFF);
        textPaint.setTextSize(dp(12));
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setShadowLayer(dp(2), 0, dp(1), 0xCC000000);
        setOnDragListener((v,e) -> handleDrag(e));
    }

    public void setPageIndex(int page) { pageIndex = page; }
    public int getPageIndex() { return pageIndex; }
    public void setOnReorderListener(OnReorderListener l) { reorderListener = l; }

    public void updateGridForOrientation(boolean landscape) {
        columns = landscape ? 6 : 4;
        rows = landscape ? 3 : 4;
        setColumnCount(columns);
        setRowCount(rows);
        relayoutChildren();
    }

    public int capacity() { return columns * rows; }

    public void addDesktopItem(View child, int slot) {
        child.setTag(com.example.htcflyerlauncher.R.id.desktop_slot, slot);
        if (child.getTag(com.example.htcflyerlauncher.R.id.desktop_span_x) == null)
            child.setTag(com.example.htcflyerlauncher.R.id.desktop_span_x, 1);
        if (child.getTag(com.example.htcflyerlauncher.R.id.desktop_span_y) == null)
            child.setTag(com.example.htcflyerlauncher.R.id.desktop_span_y, 1);
        child.setOnLongClickListener(v -> {
            Integer s = (Integer)v.getTag(com.example.htcflyerlauncher.R.id.desktop_slot);
            if (s == null) return false;
            ClipData data = ClipData.newPlainText("slot", String.valueOf(s));
            v.startDragAndDrop(data, new View.DragShadowBuilder(v), s, 0);
            v.setAlpha(.35f);
            return true;
        });
        addView(child);
        relayoutChildren();
    }

    public void removeDesktopItem(View child) {
        removeView(child);
        relayoutChildren();
    }

    public int nextFreeSlot() {
        boolean[] used = new boolean[capacity()];
        for (int i=0;i<getChildCount();i++) {
            Integer s = (Integer)getChildAt(i).getTag(com.example.htcflyerlauncher.R.id.desktop_slot);
            if (s != null && s >= 0 && s < used.length) used[s] = true;
        }
        for (int i=0;i<used.length;i++) if (!used[i]) return i;
        return -1;
    }

    private void relayoutChildren() {
        for (int i=0;i<getChildCount();i++) {
            View child = getChildAt(i);
            Integer slot = (Integer)child.getTag(com.example.htcflyerlauncher.R.id.desktop_slot);
            if (slot == null) slot = i;
            int row = Math.max(0, slot / columns);
            int col = Math.max(0, slot % columns);
            Integer spanXTag = (Integer)child.getTag(com.example.htcflyerlauncher.R.id.desktop_span_x);
            Integer spanYTag = (Integer)child.getTag(com.example.htcflyerlauncher.R.id.desktop_span_y);
            int spanX = spanXTag == null ? 1 : Math.max(1, Math.min(columns-col, spanXTag));
            int spanY = spanYTag == null ? 1 : Math.max(1, Math.min(rows-row, spanYTag));
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                    GridLayout.spec(row,spanY,1f), GridLayout.spec(col,spanX,1f));
            lp.width = 0;
            lp.height = 0;
            lp.setGravity(Gravity.FILL);
            lp.setMargins(dp(4),dp(4),dp(4),dp(4));
            child.setLayoutParams(lp);
        }
        requestLayout();
    }

    private boolean handleDrag(DragEvent e) {
        if (e.getAction() == DragEvent.ACTION_DROP) {
            Object local = e.getLocalState();
            if (!(local instanceof Integer)) return false;
            int from = (Integer)local;
            int cellW = Math.max(1, getWidth()/columns);
            int cellH = Math.max(1, getHeight()/rows);
            int col = Math.max(0, Math.min(columns-1, (int)(e.getX()/cellW)));
            int row = Math.max(0, Math.min(rows-1, (int)(e.getY()/cellH)));
            int to = row * columns + col;
            View dragged = findChildBySlot(from);
            View occupied = findChildBySlot(to);
            if (dragged != null) {
                if (occupied != null && occupied != dragged) occupied.setTag(com.example.htcflyerlauncher.R.id.desktop_slot, from);
                dragged.setTag(com.example.htcflyerlauncher.R.id.desktop_slot, to);
                if (reorderListener != null) reorderListener.onReorder(pageIndex, from, to);
                relayoutChildren();
                dragged.setAlpha(1f);
            }
            return true;
        }
        if (e.getAction() == DragEvent.ACTION_DRAG_ENDED) {
            for(int i=0;i<getChildCount();i++) getChildAt(i).setAlpha(1f);
        }
        return true;
    }

    private View findChildBySlot(int slot) {
        for (int i=0;i<getChildCount();i++) {
            Integer s=(Integer)getChildAt(i).getTag(com.example.htcflyerlauncher.R.id.desktop_slot);
            if (s!=null && s==slot) return getChildAt(i);
        }
        return null;
    }

    private int dp(float v){ return Math.round(v*getResources().getDisplayMetrics().density); }


    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float inset = dp(8);
        RectF r = new RectF(inset, dp(24), getWidth()-inset, getHeight()-dp(10));
        canvas.drawRoundRect(r, dp(14), dp(14), pagePaint);
        canvas.drawText("SCREEN " + (pageIndex + 1) + " OF " + FlyerCarouselView.PAGE_COUNT,
                getWidth()/2f, dp(20), textPaint);
    }

}
