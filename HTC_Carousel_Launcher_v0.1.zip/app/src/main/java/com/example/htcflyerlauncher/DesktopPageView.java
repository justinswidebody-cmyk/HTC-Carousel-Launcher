package com.example.htcflyerlauncher;

import android.content.ClipData;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;

public class DesktopPageView extends FrameLayout {
    private int pageIndex;
    private int columns=4;
    private int rows=4;
    private OnReorderListener reorderListener;
    private boolean editMode=false;

    private final Paint borderPaint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gridPaint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint editFillPaint=new Paint(Paint.ANTI_ALIAS_FLAG);

    public interface OnReorderListener {
        void onReorder(int page,int from,int to);
    }

    public DesktopPageView(Context context){
        super(context);
        setPadding(dp(14),dp(36),dp(14),dp(16));
        setBackgroundColor(Color.TRANSPARENT);
        setWillNotDraw(false);
        setClipChildren(false);
        setClipToPadding(false);

        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(dp(1));
        borderPaint.setColor(0x18FFFFFF);

        textPaint.setColor(0x88FFFFFF);
        textPaint.setTextSize(dp(11));
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setShadowLayer(dp(2),0,dp(1),0xCC000000);

        gridPaint.setStyle(Paint.Style.STROKE);
        gridPaint.setStrokeWidth(dp(1));
        gridPaint.setColor(0xB8FFFFFF);

        editFillPaint.setStyle(Paint.Style.FILL);
        editFillPaint.setColor(0x24000000);

        setOnDragListener((v,e)->handleDrag(e));
    }

    public void setPageIndex(int page){ pageIndex=page; }
    public int getPageIndex(){ return pageIndex; }
    public void setOnReorderListener(OnReorderListener l){ reorderListener=l; }

    public void setEditMode(boolean enabled){
        editMode=enabled;
        for(int i=0;i<getChildCount();i++){
            View child=getChildAt(i);
            if(child instanceof WidgetFrame) ((WidgetFrame)child).setEditMode(enabled);
        }
        invalidate();
    }

    public boolean isEditMode(){ return editMode; }

    public void updateGridForOrientation(boolean landscape){
        columns=landscape?6:4;
        rows=landscape?3:4;
        for(int i=0;i<getChildCount();i++){
            View child=getChildAt(i);
            if(child instanceof WidgetFrame) ((WidgetFrame)child).setGridLimits(columns,rows);
        }
        requestLayout();
        invalidate();
    }

    public int getDesktopColumns(){ return columns; }
    public int getDesktopRows(){ return rows; }
    public int capacity(){ return columns*rows; }

    public void addDesktopItem(View child,int slot){
        child.setTag(R.id.desktop_slot,slot);
        if(child.getTag(R.id.desktop_span_x)==null) child.setTag(R.id.desktop_span_x,1);
        if(child.getTag(R.id.desktop_span_y)==null) child.setTag(R.id.desktop_span_y,1);

        if(!(child instanceof WidgetFrame)){
            child.setOnLongClickListener(v->{
                Integer s=(Integer)v.getTag(R.id.desktop_slot);
                if(s==null) return false;
                ClipData data=ClipData.newPlainText("slot",String.valueOf(s));
                v.startDragAndDrop(data,new View.DragShadowBuilder(v),s,0);
                v.setAlpha(.35f);
                return true;
            });
        }

        addView(child,new FrameLayout.LayoutParams(dp(80),dp(80)));
        if(child instanceof WidgetFrame) ((WidgetFrame)child).setEditMode(editMode);
        requestLayout();
    }

    public int nextFreeSlot(){
        boolean[] used=new boolean[capacity()];
        for(int i=0;i<getChildCount();i++){
            Integer slot=(Integer)getChildAt(i).getTag(R.id.desktop_slot);
            if(slot!=null && slot>=0 && slot<used.length) used[slot]=true;
        }
        for(int i=0;i<used.length;i++) if(!used[i]) return i;
        return -1;
    }

    public void refreshLayout(){
        requestLayout();
        invalidate();
    }

    public android.graphics.Rect cellRectFor(int slot,int spanX,int spanY){
        int usableW=Math.max(1,getWidth()-getPaddingLeft()-getPaddingRight());
        int usableH=Math.max(1,getHeight()-getPaddingTop()-getPaddingBottom());
        int cellW=Math.max(1,usableW/columns);
        int cellH=Math.max(1,usableH/rows);
        int col=Math.max(0,Math.min(columns-1,slot%columns));
        int row=Math.max(0,Math.min(rows-1,slot/columns));
        spanX=Math.max(1,Math.min(columns-col,spanX));
        spanY=Math.max(1,Math.min(rows-row,spanY));
        int left=getPaddingLeft()+col*cellW+dp(4);
        int top=getPaddingTop()+row*cellH+dp(4);
        int width=Math.max(dp(48),cellW*spanX-dp(8));
        int height=Math.max(dp(48),cellH*spanY-dp(8));
        return new android.graphics.Rect(left,top,left+width,top+height);
    }

    public void setExactRect(View child,android.graphics.Rect rect){
        if(rect==null) return;
        child.setTag(R.id.desktop_exact_left,rect.left);
        child.setTag(R.id.desktop_exact_top,rect.top);
        child.setTag(R.id.desktop_exact_width,rect.width());
        child.setTag(R.id.desktop_exact_height,rect.height());
        requestLayout();
    }

    public void clearExactRect(View child){
        child.setTag(R.id.desktop_exact_left,null);
        child.setTag(R.id.desktop_exact_top,null);
        child.setTag(R.id.desktop_exact_width,null);
        child.setTag(R.id.desktop_exact_height,null);
        requestLayout();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec,int heightMeasureSpec){
        super.onMeasure(widthMeasureSpec,heightMeasureSpec);

        int usableW=Math.max(1,getMeasuredWidth()-getPaddingLeft()-getPaddingRight());
        int usableH=Math.max(1,getMeasuredHeight()-getPaddingTop()-getPaddingBottom());
        int cellW=Math.max(1,usableW/columns);
        int cellH=Math.max(1,usableH/rows);

        for(int i=0;i<getChildCount();i++){
            View child=getChildAt(i);
            Integer slot=(Integer)child.getTag(R.id.desktop_slot);
            if(slot==null) slot=i;
            int col=Math.max(0,Math.min(columns-1,slot%columns));
            int row=Math.max(0,Math.min(rows-1,slot/columns));

            Integer exactW=(Integer)child.getTag(R.id.desktop_exact_width);
            Integer exactH=(Integer)child.getTag(R.id.desktop_exact_height);
            int w,h;
            if(child instanceof WidgetFrame && exactW!=null && exactH!=null && exactW>0 && exactH>0){
                w=exactW;
                h=exactH;
            } else {
                Integer sxTag=(Integer)child.getTag(R.id.desktop_span_x);
                Integer syTag=(Integer)child.getTag(R.id.desktop_span_y);
                int spanX=sxTag==null?1:Math.max(1,Math.min(columns-col,sxTag));
                int spanY=syTag==null?1:Math.max(1,Math.min(rows-row,syTag));
                w=Math.max(dp(48),cellW*spanX-dp(8));
                h=Math.max(dp(48),cellH*spanY-dp(8));
            }
            child.measure(
                    MeasureSpec.makeMeasureSpec(w,MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(h,MeasureSpec.EXACTLY)
            );
        }
    }

    @Override
    protected void onLayout(boolean changed,int l,int t,int r,int b){
        int usableW=Math.max(1,getWidth()-getPaddingLeft()-getPaddingRight());
        int usableH=Math.max(1,getHeight()-getPaddingTop()-getPaddingBottom());
        int cellW=Math.max(1,usableW/columns);
        int cellH=Math.max(1,usableH/rows);

        for(int i=0;i<getChildCount();i++){
            View child=getChildAt(i);
            Integer slot=(Integer)child.getTag(R.id.desktop_slot);
            if(slot==null) slot=i;
            int col=Math.max(0,Math.min(columns-1,slot%columns));
            int row=Math.max(0,Math.min(rows-1,slot/columns));

            Integer exactLeft=(Integer)child.getTag(R.id.desktop_exact_left);
            Integer exactTop=(Integer)child.getTag(R.id.desktop_exact_top);
            int left=(child instanceof WidgetFrame && exactLeft!=null)
                    ? exactLeft : getPaddingLeft()+col*cellW+dp(4);
            int top=(child instanceof WidgetFrame && exactTop!=null)
                    ? exactTop : getPaddingTop()+row*cellH+dp(4);
            child.layout(left,top,left+child.getMeasuredWidth(),top+child.getMeasuredHeight());
        }
    }

    @Override
    protected void onDraw(Canvas canvas){
        super.onDraw(canvas);

        if(!editMode) return;

        RectF pageRect=new RectF(dp(8),dp(8),getWidth()-dp(8),getHeight()-dp(8));
        canvas.drawRoundRect(pageRect,dp(14),dp(14),editFillPaint);

        float left=getPaddingLeft();
        float top=getPaddingTop();
        float usableW=getWidth()-getPaddingLeft()-getPaddingRight();
        float usableH=getHeight()-getPaddingTop()-getPaddingBottom();
        float cellW=usableW/columns;
        float cellH=usableH/rows;

        for(int c=0;c<=columns;c++){
            float x=left+c*cellW;
            canvas.drawLine(x,top,x,top+usableH,gridPaint);
        }
        for(int rr=0;rr<=rows;rr++){
            float y=top+rr*cellH;
            canvas.drawLine(left,y,left+usableW,y,gridPaint);
        }
    }

    private boolean handleDrag(DragEvent e){
        if(e.getAction()==DragEvent.ACTION_DROP){
            Object local=e.getLocalState();
            if(!(local instanceof Integer)) return false;
            int from=(Integer)local;

            float usableW=Math.max(1,getWidth()-getPaddingLeft()-getPaddingRight());
            float usableH=Math.max(1,getHeight()-getPaddingTop()-getPaddingBottom());
            float localX=e.getX()-getPaddingLeft();
            float localY=e.getY()-getPaddingTop();
            int col=Math.max(0,Math.min(columns-1,(int)(localX/(usableW/columns))));
            int row=Math.max(0,Math.min(rows-1,(int)(localY/(usableH/rows))));
            int to=row*columns+col;

            View dragged=findChildBySlot(from);
            View occupied=findChildBySlot(to);
            if(dragged!=null){
                if(occupied!=null && occupied!=dragged) occupied.setTag(R.id.desktop_slot,from);
                dragged.setTag(R.id.desktop_slot,to);
                if(reorderListener!=null) reorderListener.onReorder(pageIndex,from,to);
                dragged.setAlpha(1f);
                requestLayout();
            }
            return true;
        }
        if(e.getAction()==DragEvent.ACTION_DRAG_ENDED){
            for(int i=0;i<getChildCount();i++) getChildAt(i).setAlpha(1f);
        }
        return true;
    }

    private View findChildBySlot(int slot){
        for(int i=0;i<getChildCount();i++){
            Integer s=(Integer)getChildAt(i).getTag(R.id.desktop_slot);
            if(s!=null && s==slot) return getChildAt(i);
        }
        return null;
    }

    private int dp(float v){ return Math.round(v*getResources().getDisplayMetrics().density); }
}
