package com.example.htcflyerlauncher;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.drawable.Drawable;
import org.xmlpull.v1.XmlPullParser;
import java.util.*;

public class IconPackManager {
    public static class Pack {
        public final String packageName;
        public final String label;
        public Pack(String p, String l) { packageName=p; label=l; }
        @Override public String toString(){ return label; }
    }

    private final Context context;
    private String selectedPackage;
    private Resources packResources;
    private final Map<String,String> componentMap = new HashMap<>();

    public IconPackManager(Context context) {
        this.context = context.getApplicationContext();
        selectedPackage = context.getSharedPreferences("launcher", Context.MODE_PRIVATE)
                .getString("icon_pack", "");
        loadSelected();
    }

    public String selectedPackage(){ return selectedPackage; }

    public List<Pack> listPacks() {
        LinkedHashMap<String,Pack> result = new LinkedHashMap<>();
        result.put("", new Pack("", "System icons"));
        PackageManager pm = context.getPackageManager();
        for (String action : new String[]{"com.novalauncher.THEME","org.adw.launcher.THEMES"}) {
            for (ResolveInfo ri : pm.queryIntentActivities(new Intent(action), PackageManager.MATCH_ALL)) {
                String p = ri.activityInfo.packageName;
                CharSequence label = ri.loadLabel(pm);
                result.put(p, new Pack(p, label == null ? p : label.toString()));
            }
        }
        return new ArrayList<>(result.values());
    }

    public void select(String packageName) {
        selectedPackage = packageName == null ? "" : packageName;
        context.getSharedPreferences("launcher",Context.MODE_PRIVATE)
                .edit().putString("icon_pack",selectedPackage).apply();
        loadSelected();
    }

    private void loadSelected() {
        componentMap.clear();
        packResources = null;
        if (selectedPackage == null || selectedPackage.isEmpty()) return;
        try {
            PackageManager pm = context.getPackageManager();
            packResources = pm.getResourcesForApplication(selectedPackage);
            int id = packResources.getIdentifier("appfilter","xml",selectedPackage);
            if (id == 0) return;
            XmlResourceParser parser = packResources.getXml(id);
            int type;
            while ((type = parser.next()) != XmlPullParser.END_DOCUMENT) {
                if (type == XmlPullParser.START_TAG && "item".equals(parser.getName())) {
                    String component = parser.getAttributeValue(null,"component");
                    String drawable = parser.getAttributeValue(null,"drawable");
                    if (component != null && drawable != null) componentMap.put(normalize(component), drawable);
                }
            }
            parser.close();
        } catch (Throwable ignored) {
            packResources = null;
            componentMap.clear();
        }
    }

    private String normalize(String s) {
        s = s.trim();
        if (s.startsWith("ComponentInfo{")) s = s.substring("ComponentInfo{".length());
        if (s.endsWith("}")) s = s.substring(0,s.length()-1);
        return s;
    }

    public Drawable iconFor(ComponentName cn, Drawable fallback) {
        if (packResources == null || cn == null) return fallback;
        String full = cn.getPackageName()+"/"+cn.getClassName();
        String name = componentMap.get(full);
        if (name == null && cn.getClassName().startsWith(cn.getPackageName()+".")) {
            String shortName = cn.getPackageName()+"/."+cn.getClassName().substring(cn.getPackageName().length()+1);
            name = componentMap.get(shortName);
        }
        if (name == null) return fallback;
        try {
            int id = packResources.getIdentifier(name,"drawable",selectedPackage);
            if (id == 0) id = packResources.getIdentifier(name,"mipmap",selectedPackage);
            if (id != 0) return packResources.getDrawable(id, context.getTheme());
        } catch (Throwable ignored) {}
        return fallback;
    }
}
