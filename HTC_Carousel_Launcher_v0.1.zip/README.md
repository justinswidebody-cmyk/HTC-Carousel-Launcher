# HTC Flyer Carousel Launcher v0.2

A modern Android HOME launcher prototype inspired by the HTC Flyer / tablet-era HTC Sense launcher.

## Working in this build
- Android HOME launcher role
- 8 home screens
- HTC-style 3D page carousel
- Portrait and landscape reflow
- Flyer-style bottom launch bar
- Page indicator dots
- Leap-style 8-screen overview
- All Apps drawer
- Tap app to launch
- Long-press app in All Apps to add it to the current home screen
- Persistent desktop shortcuts
- Drag desktop items to reorder grid positions
- Android AppWidget picker / host / configuration flow
- Persistent widgets
- Wallpaper display and wallpaper picker entry
- Nova/ADW-style third-party icon packs using appfilter.xml
- Icon pack selector in Settings

Portrait uses a 4x4 desktop grid. Landscape reflows to a wider 6x3 grid.

## Build
The included GitHub Action builds with Android API 36, Java 17 and Gradle 8.13.
The APK is uploaded as the `HTC-Flyer-Launcher` artifact.
