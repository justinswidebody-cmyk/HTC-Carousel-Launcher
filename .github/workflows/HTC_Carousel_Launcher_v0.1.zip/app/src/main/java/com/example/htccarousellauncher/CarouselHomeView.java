package com.example.htccarousellauncher;

import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;

public class CarouselHomeView extends HorizontalScrollView {
    public static final int PAGE_COUNT = 7;
    private final LinearLayout strip;
    private final FrameLayout[] pages = new FrameLayout[PAGE_COUNT];
    private int currentPage = 3;
    private float downX;
    private boolean carouselEnabled = true;

    public CarouselHomeView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setFillViewport(true);
        setHorizontalScrollBarEnabled(false);
        setOverScrollMode(OVER_SCROLL_NEVER);
        setClipChildren(false);
        setClipToPadding(false);

        strip = new LinearLayout(context);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        strip.setClipChildren(false);
        strip.setClipToPadding(false);
        addView(strip, new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.MATCH_PARENT));

        for (int i = 0; i < PAGE_COUNT; i++) {
            FrameLayout page = new FrameLayout(context);
            page.setBackgroundColor(Color.TRANSPARENT);
            page.setClipChildren(false);
            pages[i] = page;
            strip.addView(page, new LinearLayout.LayoutParams(1, LayoutParams.MATCH_PARENT));
        }
    }

    public void setCarouselEnabled(boolean enabled) {
        carouselEnabled = enabled;
        applyTransforms();
    }

    public FrameLayout getCurrentPageContainer() { return pages[currentPage]; }
    public FrameLayout getPageContainer(int page) {
        if (page < 0 || page >= PAGE_COUNT) return pages[3];
        return pages[page];
    }
    public int getCurrentPage() { return currentPage; }

    public void goToPage(int page, boolean smooth) {
        currentPage = Math.max(0, Math.min(PAGE_COUNT - 1, page));
        int x = currentPage * getWidth();
        if (smooth) smoothScrollTo(x, 0); else scrollTo(x, 0);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w <= 0) return;
        for (FrameLayout page : pages) {
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) page.getLayoutParams();
            lp.width = w;
            lp.height = h;
            page.setLayoutParams(lp);
        }
        strip.requestLayout();
        post(() -> goToPage(currentPage, false));
    }

    @Override
    protected void onScrollChanged(int l, int t, int oldl, int oldt) {
        super.onScrollChanged(l, t, oldl, oldt);
        if (getWidth() > 0) {
            currentPage = Math.max(0, Math.min(PAGE_COUNT - 1,
                    Math.round((float) l / (float) getWidth())));
        }
        applyTransforms();
    }

    private void applyTransforms() {
        if (getWidth() <= 0) return;
        float center = getScrollX() + getWidth() / 2f;
        for (FrameLayout page : pages) {
            float pageCenter = page.getLeft() + page.getWidth() / 2f;
            float delta = (pageCenter - center) / getWidth();
            float abs = Math.min(1f, Math.abs(delta));
            if (carouselEnabled) {
                page.setPivotX(delta < 0 ? page.getWidth() : 0f);
                page.setPivotY(page.getHeight() * .48f);
                page.setRotationY(-delta * 42f);
                float scale = 1f - abs * .13f;
                page.setScaleX(scale);
                page.setScaleY(scale);
                page.setAlpha(1f - abs * .22f);
                page.setTranslationZ((1f - abs) * 18f);
            } else {
                page.setRotationY(0f);
                page.setScaleX(1f);
                page.setScaleY(1f);
                page.setAlpha(1f);
                page.setTranslationZ(0f);
            }
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        if (ev.getActionMasked() == MotionEvent.ACTION_DOWN) downX = ev.getX();
        boolean handled = super.onTouchEvent(ev);
        if (ev.getActionMasked() == MotionEvent.ACTION_UP ||
                ev.getActionMasked() == MotionEvent.ACTION_CANCEL) {
            float dx = ev.getX() - downX;
            int target = getWidth() > 0 ? Math.round((float) getScrollX() / getWidth()) : currentPage;
            if (Math.abs(dx) > getWidth() * .17f) {
                if (dx < 0) target = Math.min(PAGE_COUNT - 1, currentPage + 1);
                else target = Math.max(0, currentPage - 1);
            }
            goToPage(target, true);
        }
        return handled;
    }
}
