package com.example.htccarousellauncher;
import android.content.Context;
import android.content.ComponentName;
import android.content.pm.*;
import android.graphics.drawable.Drawable;
import android.view.*;
import android.widget.*;
import java.util.*;

public class AppGridAdapter extends BaseAdapter {
    private final Context c; private final List<ResolveInfo> apps; private final PackageManager pm; private final IconPackManager packs;
    public AppGridAdapter(Context c,List<ResolveInfo> apps,IconPackManager packs){this.c=c;this.apps=apps;this.pm=c.getPackageManager();this.packs=packs;}
    public int getCount(){return apps.size();}
    public Object getItem(int p){return apps.get(p);}
    public long getItemId(int p){return p;}
    public View getView(int p,View v,ViewGroup parent){
        if(v==null)v=LayoutInflater.from(c).inflate(R.layout.app_cell,parent,false);
        ResolveInfo ri=apps.get(p);
        ((TextView)v.findViewById(R.id.label)).setText(ri.loadLabel(pm));
        Drawable fallback=ri.loadIcon(pm);
        ((ImageView)v.findViewById(R.id.icon)).setImageDrawable(packs.iconFor(new ComponentName(ri.activityInfo.packageName,ri.activityInfo.name),fallback));
        return v;
    }
}
