package com.example.htccarousellauncher;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.drawable.Drawable;
import org.xmlpull.v1.XmlPullParser;
import java.util.*;

public class IconPackManager {
    public static class Pack {
        public final String packageName, label;
        public Pack(String p, String l){ packageName=p; label=l; }
        @Override public String toString(){ return label; }
    }
    private final Context context;
    private String selectedPackage;
    private Resources res;
    private final Map<String,String> map=new HashMap<>();

    public IconPackManager(Context c){
        context=c.getApplicationContext();
        selectedPackage=context.getSharedPreferences("launcher",Context.MODE_PRIVATE).getString("icon_pack","");
        load();
    }

    public List<Pack> listPacks(){
        LinkedHashMap<String,Pack> out=new LinkedHashMap<>();
        out.put("",new Pack("","System icons"));
        PackageManager pm=context.getPackageManager();
        for(String a:new String[]{"com.novalauncher.THEME","org.adw.launcher.THEMES"}){
            for(ResolveInfo ri:pm.queryIntentActivities(new Intent(a),PackageManager.MATCH_ALL)){
                String p=ri.activityInfo.packageName;
                CharSequence l=ri.loadLabel(pm);
                out.put(p,new Pack(p,l==null?p:l.toString()));
            }
        }
        return new ArrayList<>(out.values());
    }

    public String selectedPackage(){ return selectedPackage; }
    public void select(String p){
        selectedPackage=p==null?"":p;
        context.getSharedPreferences("launcher",Context.MODE_PRIVATE).edit().putString("icon_pack",selectedPackage).apply();
        load();
    }

    private void load(){
        map.clear(); res=null;
        if(selectedPackage==null||selectedPackage.isEmpty()) return;
        try{
            res=context.getPackageManager().getResourcesForApplication(selectedPackage);
            int id=res.getIdentifier("appfilter","xml",selectedPackage);
            if(id==0) return;
            XmlResourceParser x=res.getXml(id);
            int type;
            while((type=x.next())!=XmlPullParser.END_DOCUMENT){
                if(type==XmlPullParser.START_TAG && "item".equals(x.getName())){
                    String c=x.getAttributeValue(null,"component");
                    String d=x.getAttributeValue(null,"drawable");
                    if(c!=null&&d!=null) map.put(norm(c),d);
                }
            }
            x.close();
        }catch(Throwable e){ res=null; map.clear(); }
    }

    private String norm(String s){
        s=s.trim();
        if(s.startsWith("ComponentInfo{")) s=s.substring(14);
        if(s.endsWith("}")) s=s.substring(0,s.length()-1);
        return s;
    }

    public Drawable iconFor(ComponentName cn, Drawable fallback){
        if(res==null||cn==null) return fallback;
        String name=map.get(cn.getPackageName()+"/"+cn.getClassName());
        if(name==null && cn.getClassName().startsWith(cn.getPackageName()+"."))
            name=map.get(cn.getPackageName()+"/."+cn.getClassName().substring(cn.getPackageName().length()+1));
        if(name==null) return fallback;
        try{
            int id=res.getIdentifier(name,"drawable",selectedPackage);
            if(id==0) id=res.getIdentifier(name,"mipmap",selectedPackage);
            if(id!=0) return res.getDrawable(id,context.getTheme());
        }catch(Throwable ignored){}
        return fallback;
    }
}
