package com.example.htccarousellauncher;

import android.app.*;
import android.appwidget.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class LauncherActivity extends Activity {
    private static final int HOST_ID = 0x485443;
    private static final int REQ_PICK_WIDGET = 1001;
    private static final int REQ_CONFIG_WIDGET = 1002;

    private CarouselHomeView carousel;
    private FrameLayout drawer;
    private GridView appGrid;
    private IconPackManager iconPacks;
    private AppWidgetHost widgetHost;
    private AppWidgetManager widgetManager;
    private final Map<Integer,Integer> widgetPages = new LinkedHashMap<>();
    private int pendingWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private int pendingPage = 3;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);

        setContentView(R.layout.activity_launcher);
        carousel=findViewById(R.id.carousel);
        drawer=findViewById(R.id.drawer);
        appGrid=findViewById(R.id.app_grid);

        widgetManager=AppWidgetManager.getInstance(this);
        widgetHost=new AppWidgetHost(this,HOST_ID);
        iconPacks=new IconPackManager(this);

        findViewById(R.id.apps).setOnClickListener(v->toggleDrawer());
        findViewById(R.id.settings).setOnClickListener(v->
                startActivity(new Intent(this,LauncherSettingsActivity.class)));
        findViewById(R.id.phone).setOnClickListener(v->{
            try{ startActivity(new Intent(Intent.ACTION_DIAL)); }catch(Throwable ignored){}
        });
        findViewById(R.id.add_widget).setOnClickListener(v->pickWidget());

        loadWallpaper();
        setupApps();
        restoreWidgets();
        carousel.post(()->carousel.goToPage(3,false));
    }

    @Override protected void onStart(){
        super.onStart();
        try{widgetHost.startListening();}catch(Throwable ignored){}
    }

    @Override protected void onStop(){
        super.onStop();
        try{widgetHost.stopListening();}catch(Throwable ignored){}
    }

    @Override protected void onResume(){
        super.onResume();
        carousel.setCarouselEnabled(getSharedPreferences("launcher",MODE_PRIVATE)
                .getBoolean("carousel_effect",true));
        iconPacks=new IconPackManager(this);
        setupApps();
    }

    private void loadWallpaper(){
        try{
            android.graphics.drawable.Drawable d=WallpaperManager.getInstance(this).getDrawable();
            findViewById(R.id.root).setBackground(d);
        }catch(Throwable ignored){
            findViewById(R.id.root).setBackgroundColor(Color.rgb(22,25,27));
        }
    }

    private void setupApps(){
        Intent intent=new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps=getPackageManager().queryIntentActivities(intent,0);
        apps.sort(Comparator.comparing(a->String.valueOf(a.loadLabel(getPackageManager())),String.CASE_INSENSITIVE_ORDER));
        appGrid.setAdapter(new AppGridAdapter(this,apps,iconPacks));
        appGrid.setOnItemClickListener((p,v,pos,id)->{
            ResolveInfo ri=apps.get(pos);
            Intent launch=new Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(new ComponentName(ri.activityInfo.packageName,ri.activityInfo.name))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            try{startActivity(launch); drawer.setVisibility(View.GONE);}catch(Throwable ignored){}
        });
    }

    private void toggleDrawer(){
        drawer.setVisibility(drawer.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE);
    }

    private void pickWidget(){
        pendingPage=carousel.getCurrentPage();
        pendingWidgetId=widgetHost.allocateAppWidgetId();
        Intent pick=new Intent(AppWidgetManager.ACTION_APPWIDGET_PICK);
        pick.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,pendingWidgetId);
        try{startActivityForResult(pick,REQ_PICK_WIDGET);}
        catch(Throwable e){widgetHost.deleteAppWidgetId(pendingWidgetId); pendingWidgetId=AppWidgetManager.INVALID_APPWIDGET_ID;}
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        int id=data!=null?data.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,pendingWidgetId):pendingWidgetId;
        if(resultCode!=RESULT_OK || id==AppWidgetManager.INVALID_APPWIDGET_ID){
            if(id!=AppWidgetManager.INVALID_APPWIDGET_ID) try{widgetHost.deleteAppWidgetId(id);}catch(Throwable ignored){}
            pendingWidgetId=AppWidgetManager.INVALID_APPWIDGET_ID;
            return;
        }

        if(requestCode==REQ_PICK_WIDGET){
            AppWidgetProviderInfo info=widgetManager.getAppWidgetInfo(id);
            if(info!=null && info.configure!=null){
                Intent cfg=new Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE);
                cfg.setComponent(info.configure);
                cfg.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id);
                try{startActivityForResult(cfg,REQ_CONFIG_WIDGET); return;}
                catch(Throwable ignored){}
            }
            addWidget(id,pendingPage,true);
        }else if(requestCode==REQ_CONFIG_WIDGET){
            addWidget(id,pendingPage,true);
        }
    }

    private int dp(float v){return Math.round(v*getResources().getDisplayMetrics().density);}

    private void addWidget(int id,int page,boolean save){
        AppWidgetProviderInfo info=widgetManager.getAppWidgetInfo(id);
        if(info==null) return;
        AppWidgetHostView host=widgetHost.createView(this,id,info);
        host.setAppWidget(id,info);
        FrameLayout parent=carousel.getPageContainer(page);

        int minW=Math.max(dp(180),info.minWidth>0?info.minWidth:dp(280));
        int minH=Math.max(dp(120),info.minHeight>0?info.minHeight:dp(190));
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(minW,minH);
        lp.gravity=Gravity.TOP|Gravity.CENTER_HORIZONTAL;
        lp.topMargin=dp(72 + (widgetPages.size()%2)*16);
        parent.addView(host,lp);

        host.setOnLongClickListener(v->{
            parent.removeView(v);
            try{widgetHost.deleteAppWidgetId(id);}catch(Throwable ignored){}
            widgetPages.remove(id); saveWidgets();
            Toast.makeText(this,"Widget removed",Toast.LENGTH_SHORT).show();
            return true;
        });

        widgetPages.put(id,page);
        if(save) saveWidgets();
        pendingWidgetId=AppWidgetManager.INVALID_APPWIDGET_ID;
    }

    private void saveWidgets(){
        StringBuilder b=new StringBuilder();
        for(Map.Entry<Integer,Integer> e:widgetPages.entrySet()){
            if(b.length()>0)b.append(",");
            b.append(e.getKey()).append(":").append(e.getValue());
        }
        getSharedPreferences("launcher",MODE_PRIVATE).edit().putString("widgets",b.toString()).apply();
    }

    private void restoreWidgets(){
        String s=getSharedPreferences("launcher",MODE_PRIVATE).getString("widgets","");
        if(s==null||s.isEmpty())return;
        for(String part:s.split(",")){
            try{
                String[] kv=part.split(":");
                int id=Integer.parseInt(kv[0]);
                int page=Integer.parseInt(kv[1]);
                if(widgetManager.getAppWidgetInfo(id)!=null) addWidget(id,page,false);
            }catch(Throwable ignored){}
        }
    }

    @Override public void onBackPressed(){
        if(drawer.getVisibility()==View.VISIBLE){drawer.setVisibility(View.GONE);return;}
        carousel.goToPage(3,true);
    }

    @Override public void onConfigurationChanged(android.content.res.Configuration newConfig){
        super.onConfigurationChanged(newConfig);
        carousel.post(()->carousel.goToPage(carousel.getCurrentPage(),false));
    }
}
