package com.example.htccarousellauncher;
import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import java.util.*;

public class LauncherSettingsActivity extends Activity{
    protected void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_settings);
        Spinner s=findViewById(R.id.icon_pack_spinner);
        Switch fx=findViewById(R.id.carousel_effect);
        IconPackManager m=new IconPackManager(this);
        List<IconPackManager.Pack> packs=m.listPacks();
        s.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,packs));
        for(int i=0;i<packs.size();i++) if(packs.get(i).packageName.equals(m.selectedPackage())) s.setSelection(i);
        fx.setChecked(getSharedPreferences("launcher",MODE_PRIVATE).getBoolean("carousel_effect",true));
        findViewById(R.id.save).setOnClickListener(v->{
            IconPackManager.Pack p=(IconPackManager.Pack)s.getSelectedItem();
            m.select(p==null?"":p.packageName);
            getSharedPreferences("launcher",MODE_PRIVATE).edit().putBoolean("carousel_effect",fx.isChecked()).apply();
            finish();
        });
    }
}
