# HTC Carousel Launcher

First working prototype of a modern Android launcher inspired by the classic HTC Sense carousel.

## Included in v0.1
- Selectable Android HOME launcher
- 7 home screens, centered on screen 4
- 3D carousel page transform
- Portrait + landscape support
- App drawer
- Android AppWidget hosting and configuration
- Widget persistence across launcher restarts
- Long-press widget removal
- Third-party icon-pack discovery for Nova/ADW style packs
- `appfilter.xml` component-to-drawable mapping
- System wallpaper background
- Launcher settings page
- GitHub Actions APK build

## Build
Push the complete project to a GitHub repository. The included workflow builds:

`app/build/outputs/apk/debug/app-debug.apk`

Run the workflow under **Actions > Build HTC Carousel Launcher**, or push to `main`.

## First launch
Install the APK and press Home. Android should offer **HTC Carousel Launcher** as a Home app.

Use **Settings** on the bottom dock to select an installed icon pack and enable/disable the carousel effect.

Use **+ Widget** to place Android widgets on the current page.

This is the foundation build. Visual HTC Sense fidelity, Leap view, drag/drop icons, folders,
dock customization, and a faster full-circle carousel can be added in later builds.
